#Bingo card, ask what number comes next, if number hit == x, if all x == win

import random
import time

def Bingo(card):
    for row in card:
        for item in row:
            print(f"{item:^10}", end=" | ")
        print()

def main():
    print("Random Bingo Card")
    print("-----------------")
    print()
    time.sleep(1)

    my2DList = [[1, 2, 3],
                [4, "Bingo", 5],
                [6, 7, 8]]

    for row in range(len(my2DList)):
        for column in range(len(my2DList[row])):
            if my2DList[row][column] != "Bingo":
                my2DList[row][column] = random.randint(1, 30)

    Bingo(my2DList)
    print()
    print("--------------------")

    while True:
        guess = input("What is the next number?: ")
        for row in my2DList:
            for item in row:
                if guess == str(item):
                    print("You got it!")
                    row[row.index(item)] = 'x'

        Bingo(my2DList)
        allX = all(item == 'x' or item == 'Bingo' for item in row for row in my2DList)
        if allX:
            print("You have won!")
            break

if __name__ == "__main__":
    main()
