import requests, json, os
import openai
import os
#https://platform.openai.com/docs/api-reference/introduction
#https://newsapi.org/docs/get-started#top-headlines

# OpenAI API
openai.organization = os.environ['organizationID']
openai.api_key = os.environ['openai']
openai.Model.list()

# NewsAPI
newsKey = os.environ['newsapi']
country = "us"
url = f"https://newsapi.org/v2/top-headlines?country={country}&apiKey={newsKey}"

# Get 5 news articles
result = requests.get(url)
data = result.json()
articles = data["articles"][:5] 

# Summarize 
for article in articles:
    prompt = f"Summarize the following news article in a funny way: {article['title']}\n\n{article['content']}"
    response = openai.Completion.create(model="text-davinci-002", prompt=prompt, temperature=0, max_tokens=60)
    summary = response["choices"][0]["text"].strip()
    print(f"Summary: {summary}\n")