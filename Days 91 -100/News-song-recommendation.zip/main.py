import requests, json, os
import openai
import os
#https://platform.openai.com/docs/api-reference/introduction
#https://newsapi.org/docs/get-started#top-headlines
# https://developer.spotify.com/dashboard

# Spotify API
def getTracks(query):
    clientID = os.environ['Spotify_ID']
    clientSecret = os.environ['Spotify_SECRET']

    url = "https://accounts.spotify.com/api/token"
    data = {"grant_type": "client_credentials"}
    auth = (clientID, clientSecret)
    response = requests.post(url, data=data, auth=auth)
    access_token = response.json()["access_token"]

    url = "https://api.spotify.com/v1/search"
    headers = {'Authorization': f'Bearer {access_token}'}
    search = f"?q={query}&type=track&limit=1"
    full_url = f"{url}{search}"

    response = requests.get(full_url, headers=headers)
    data = response.json()

    if data["tracks"]["items"]:
        track = data["tracks"]["items"][0]
        return track["name"], track["artists"][0]["name"], track["preview_url"]
    else:
        return None, None, None

# OpenAI API
openai.organization = os.environ['organizationID']
openai.api_key = os.environ['openai']

# NewsAPI
newsKey = os.environ['newsapi']
country = "us"
url = f"https://newsapi.org/v2/top-headlines?country={country}&apiKey={newsKey}"

# Get 5 news articles
result = requests.get(url)
data = result.json()
articles = data["articles"][:5] 

# Summarize each article using OpenAI and find a related song on Spotify
for article in articles:
    prompt = f"Summarize the following news article in 2 - 3 words: {article['title']}\n\n{article['content']}"
    response = openai.Completion.create(model="text-davinci-002", prompt=prompt, temperature=0, max_tokens=60)
    summary = response["choices"][0]["text"].strip()
    print(f"Summary: {summary}\n")
    spotify_query = f"{summary} song"
    track_name, artist_name, preview_url = getTracks(spotify_query)
    if track_name and artist_name and preview_url:
        print(f"Related song: {track_name} by {artist_name} - {preview_url}\n")
    else:
        print("No related song found.\n")