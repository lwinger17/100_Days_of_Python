
for i in range(0, 100):
  print(i, end ="\t")


import os, time
#Turns cursor off
print('\033[?25l', end="")
for i in range(1, 10):
  print(i)
  time.sleep(0.2)
  os.system("clear")

#Turns cursor on
print('\033[?25h', end="")

#\n Newline
#\t Tab
#\v Vertical Tab
#sep "What are you putting between commas"
#end "What to print at the end"
print("Colorful Subroutine")
print()
print("I am able to make words change color", "\033[33m", "such as this golden phrase.","\033[0m","Or I can use a bright color like" ,"\033[35m", "this rich purple", "\033[32m", "a bright green could also be good", "\033[0m", "and making this all in one print() function!", sep =" ")

