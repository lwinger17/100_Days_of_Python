import random
print("Random Language greeting Generator")
print()
greetings = ["Hello", "Guten Tag", "Bonjour", "Hola", "Konnichiwa", "God dag",]
index = random.randint(0,5)

print(f"Your random greeting is {greetings[index]}")

#timetable = ["Computer Science", "Math", "Art", "English", "Sports"]
#Starts at 0
#for lesson in timetable:
  #print(lesson)
#timetable[4] = "Science"
#print(timetable[4])
#print(f"The first class is {timetable[0]}.")

