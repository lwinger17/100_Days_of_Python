from flask import Flask, request, redirect, session, render_template_string

app = Flask(__name__)

posts = [
    {
        "title": "Post 1",
        "date": "05/20/2024",
        "text": "I don't know why it is taking so long to redirect login to this blog."
    },
    {
        "title": "Post 2",
        "date": "05/20/2024",
        "text": "I have been doing this for 2 hours :(."
    },
]


@app.route('/')
def index():
  username = request.headers["X-Replit-User-Name"]
  if username:
    with open("blog.html", "w") as f:
      f.write(f"<h1>Welcome, {username}!</h1>")
    return redirect ("/blog")
  else:
    return "Please log in to access this page."




@app.route("/blog")
def blog():
  username = request.headers["X-Replit-User-Name"]
  if username:
    posts = [
      {
        "title": "Post 1",
        "date": "05/20/2024",
        "text": "I don't know why it is taking so long to redirect login to this blog."
      },
      {
        "title": "Post 2",
        "date": "05/20/2024",
        "text": "I have been doing this for 2 hours :(."
      },
    ]
    page = render_template_string("""
            <html>
            <head>
                <link rel="stylesheet" type="text/css" href="/static/css/style.css">
            </head>
            <body>
                <h1>RandomBlogSite</h1>
                <h2>{{ username }}'s Blog</h2>
                <form method="post" action="/addPost">
                    <label for="title">Title:</label><br>
                    <input type="text" id="title" name="title"><br>
                    <label for="date">Date:</label><br>
                    <input type="date" id="date" name="date"><br>
                    <label for="text">Text:</label><br>
                    <textarea id="text" name="text"></textarea><br>
                    <input type="submit" value="Add Post">
                </form>
                <hr>
            {% for post in posts %}
                <h2>{{ post.title }}</h2>
                <p>{{ post.date }}</p>
                <p>{{ post.text }}</p>
                <hr>
                  {% endfor %}
                  </body>
                  </html>
                  """,
                                  username=username,
                                  posts=posts)
    return page
  else:
    return "Please log in to access this page."


@app.route("/addPost", methods=["POST"])
def addPost():
  title = request.form["title"]
  date = request.form["date"]
  text = request.form["text"]

  post = {"title": title, "date": date, "text": text}

  posts.append(post)

  return redirect("/blog")


@app.route("/setName", methods=["POST"])
def setName():
  session["myName"] = request.form["name"]
  return redirect("/")


@app.route("/reset")
def reset():
  session.clear()
  return redirect("/")


app.run(host='0.0.0.0', port=81)
