print("========= The Amazing Adventure =========")
print("Before we begin let us know about our adventurer.")
print()

name = input("What is your name?: ")
profession = input (" What is your profession? (knight, mage, tax collector, etc): ")
ability = input ("What is your special ability? (fireball, super strike, economic disruptor, etc: ")
print()

print("Our story begins with young ", name, " who is a troublesome individual who has just started working as a ", profession, ". They have decided to start their adventure because they learned the ability to ", ability, ".")
print()
print("The adventurer has just left the town and has already encountered their first dilemma. They have encountered a goblin who is trying to steal some gold from a young couple. Do you: ")

badChoice = print("\033[31m", "1. Join the goblin and steal the gold: ", "\033[31m")
neutralChoice = print ("\033[35m", "2. Ignore the goblin and young couple: " ,"\033[31m")
goodChoice = print ("\033[36m", "3. Fight the goblin:", "\033[36m")

choiceSelect = input("\033[0m" + " I choose to: " + "\033[0m")
if choiceSelect == "1":
  print(" You join the goblin and steal the gold. The goblin doesn't care about you and kills you and takes your gold.", "\033[31m", " You are dead.", "\033[31m")
elif choiceSelect == "2":
  print("You ignore the goblin and young couple and continue on your journey. You encounter a tax collector who steals your money. You are sad :(", "\033[34m", "You are depressed.", "\033[34m")
elif choiceSelect == "3":
  print( "You fight the goblin, he is too large and your attacks are ineffective. He swings his club at you and you are squished." , "\033[31m", " You are dead.", "\033[31m")
else: 
  print(" You couldn't make a choice, as the goblin flees the young couple look at you upset about the fact you didn't do anything. The young man casts limbo.")
  print()
  
  import time
  time.sleep(6)
  for i in range(1000000):
    print("\033[31m", "YOU CAN NEVER ESCAPE", "\033[31m")

