print(" Loan Calculator ")
print("------------------")
print("This will calculate your interest rate at 5% APR over a period of 10 years")
print()
loan = int(input("How much do you want to borrow? "))
print()

year = 1

while year <= 10:
    loan = loan + (loan * 0.05)
    print("Year " + str(year) + " is $" + str(round(loan, 2)))
    year += 1

print("You paid $" + str(round(loan - loan / 1.05, 2)) + " in interest!")