from getpass import getpass as input
import random

print("E P I C    🪨  📄 ✂️    B A T T L E")
player1 = input("Select your move (R, P, Or S): ")
print()
moves = ["R", "P", "S"]
player2 = random.choice(moves)

print("Player 1 > "+ player1)
print()
print("Player 2 > "+ player2)
print()

if (player1 == player2):
  print("Tie, Try Again")
elif (player1 == "R" and player2 == "S"):
  print("Player 1 Wins")
elif (player1 == "S" and player2 == "P"):
  print("Player 1 Wins")
elif (player1 == "P" and player2 == "R"):
  print("Player 1 Wins")
elif (player2 == "R" and player1 == "S"):
  print("Player 2 Wins")
elif (player2 == "S" and player1 == "P"):
  print("Player 2 Wins")
elif (player2 == "P" and player1 == "R"):
  print("Player 2 Wins")
else: 
  print("Invalid Move, use only R, P, or S")

