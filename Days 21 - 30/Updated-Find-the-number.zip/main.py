import random

print("Guess the number!")
print("Hint: the number is between 1 and 1,000,000")

attempts = 0

while True:
  for i in range(10):
    number = random.randint(1, 100000)
  guess = int(input("What is your guess?: "))
  attempts += 1
  if guess == number:
    print("Congratulations! You somehow got the right number!")
    print("It took you "+ str(attempts) + " attempts!")
    break

  elif guess > number:
    print("Too high")

  else:
    print("Too low")

    if attempts == 5:
      print("Can't help you this time. ")
    elif attempts == 10:
      print("C'mon you can do this!")
    elif attempts == 15:
      print("Can't believe this code is beating you!")