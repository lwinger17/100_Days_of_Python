# A little bit of math
So far we have introduced the computer to two types of numbers: 
- `float`: numbers with a decimal
- `int`: whole numbers

👉 Copy this code and have a go with trying the different mathematical symbols.

```python
adding = 4 + 3
print(adding)

subtraction = 8 - 9
print(subtraction)

multiplication = 4 * 32
print(multiplication)

division = 50 / 5
print(division)

# a number raised to the power of some number
# in this example we raise 5 to the power of 2
squared = 5**2
print(squared)

# remainder of a division
modulo = 15 % 4
print(modulo)

# whole number division
divisor = 15 // 2
print(divisor)
```

