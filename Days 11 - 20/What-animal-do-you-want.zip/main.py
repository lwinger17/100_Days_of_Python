exit = ""
animal = ""
while exit != "yes":
    print("Great!")
    animal = input("What animal do you want?: ")
    if animal == "cow" or "Cow":
        print("A cow goes moo.")
    elif animal == "dog" or "Dog":
        print("A dog goes woof.")
    elif animal == "cat" or "Cat":
        print("A cat goes meow.")
    elif animal == "sheep" or "Sheep":
        print("A sheep goes baa.")
    elif animal == "horse" or "Horse":
        print("A horse goes neigh.")
    else:
        print("I only know of 5 animals, a cow, dog, cat, sheep, and a horse.")
    exit = input("Do you want to exit?: ")