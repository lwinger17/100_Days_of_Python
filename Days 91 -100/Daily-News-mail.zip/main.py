import requests
from bs4 import BeautifulSoup
import schedule
import time, os, random
import smtplib
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText
from replit import db

base_url = "https://blog.replit.com/"
page_numbers = range(1, 11)

keywords = [" ai ", "artificial intelligence", "game", "app", "music"]
#searches through these words

password = os.environ['mailPassword']
username = os.environ['mailUsername']

def sendMail():
    email = "Replit News"
    server = "smtp.gmail.com"
    port = 587
    s = smtplib.SMTP(host = server, port = port) 
    s.starttls()
    s.login(username, password)

    news_list = get_news()

    if news_list:
        msg = MIMEMultipart()
        msg['To'] = "randomemail"
        #whatever emaik you wish to send it to
        msg['From'] = username 
        #Your email (will have to change secrets)
        msg['Subject'] = "Replit News" 
        msg.attach(MIMEText("\n".join(news_list), 'html'))

        # Check if the URL has been sent before
        if "sent_urls" not in db:
            db["sent_urls"] = [] 
        for news in news_list:
            href = news.split(" - ")[1]
            if href not in db["sent_urls"]:  
                s.send_message(msg)
                db["sent_urls"].append(href) 
                print(f"Sent: {href}")
                break  
        del msg 

def printMe():
  print("Replit news you might be interested in: ")
  sendMail()

schedule.every(6).hours.do(printMe)

while True:
  schedule.run_pending()
  time.sleep(1)

def get_news():
    news_list = []
    for page_number in range(1, 11):
        url = base_url + "?p=" + str(page_number)
        response = requests.get(url)
        html = response.text

        soup = BeautifulSoup(html, 'html.parser')
        links = soup.find_all("a", {"class":"css-epm014"})

        for link in links:
            title = link.text
            href = link.get("href")

            if any(keyword.lower() in title.lower() for keyword in keywords):
                news_list.append(f"{title} - {href}\n")

    return news_list