print("Character Health Stat Generator")
print("-------------------------------")
print("Enter the names of your party members to generate their health stats.")
print()

def rollDices():
  import random
  roll1 = random.randint(1,6)
  roll2 = random.randint(1,8)
  health = roll1 * roll2
  return health

while True:
  name = input("Name your warrior: ")
  health = rollDices()
  print("Your character has ", health, "hp")
  continue
  