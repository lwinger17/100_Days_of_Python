---
title: Remove `console.log`
tags: [good]
---

Remove `console.log` statements.


```grit
engine marzano(0.1)
language js

`console.log($arg)` => . where {
  $arg <: not within catch_clause()
}
```

## Removes a simple `console.log` statement

```javascript
// Do not remove this
console.error('foo');
console.log('foo');
```

```javascript
// Do not remove this
console.error('foo');
```

## Removes the statement in a function

```javascript
function f() {
  console.log('foo');
}
```

```typescript
function f() {}
```

## Works in a list as well

```javascript
server.listen(PORT, console.log(`Server started on port ${PORT}`));
```

```typescript
server.listen(PORT);
```

## Doesn't remove `console.log` in a catch clause

```javascript
try {
} catch (e) {
  console.log('foo');
}
```

## Works on multiple console logs in the same file

```javascript
// Do not remove this
console.error('foo');
console.log('foo');
console.log('bar');
```

```javascript
// Do not remove this
console.error('foo');
```
