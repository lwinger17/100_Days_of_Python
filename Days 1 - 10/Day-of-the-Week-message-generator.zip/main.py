print("Positive Message Generator")
print("===========================")
print()
name = input("What is your name?: ")
greet = input("Hello "+ name + " how was your day?: ")
if greet == "good" or greet == "Good":
  print("Well that's good.")
else:
  print("Well that's not good.")

day = input("What day of the week is it?: ")

if day == "Monday" or day == "monday":
  print("Well we all hate mondays so I hope it isn't as bad for you.")
elif day == "Tuesday" or day == "tuesday":
  print("Well at least it's not monday.")
elif day == "Wednesday" or day == "wednesday":
  print("Don't worry you're halfway there!")
elif day == "Thursday" or day == "thursday":
  print("Two more days until the weekend!")
elif day == "Friday" or day == "friday":
  print("Let's Gooooooooo!")
elif day == "Saturday" or day == "saturday":
  print("It's the weekend! Get off the Computer")
elif day == "Sunday" or day == "sunday":
  print("It's Sunday......almost monday :{")
else: 
  print("That's not a day of the week. You must be Really dumb or Really bad at typing")



