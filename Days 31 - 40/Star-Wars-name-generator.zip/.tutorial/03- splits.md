# Split

👉 `split` lets us split a string into a list of individual words by separating it at the space characters.

```python
myString = "Hello there my friend."
print(myString.split())

#This code outputs ['Hello', 'there', 'my', 'friend.']
```

### What can you split?

