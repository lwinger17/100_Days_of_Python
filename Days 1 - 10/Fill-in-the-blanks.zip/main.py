food = input("Name a food: ")
plant = input("Name a type of plant: ")
cookingMethod = input("Name a method of cooking: ")
burntFood = input("What word describes burnt food?: ")
diyItem = input ("Name a DIY item: ")
print(burntFood, plant, food, " With a side of ", cookingMethod, diyItem, ".")

foodItem = input("Does this sound appetizing?: ")
if foodItem.lower() in ("yes", "YES", "Yes"):
  print("What is wrong with you? ")
elif foodItem.lower() in ("no", "NO", "No"):
  print("That sounds about right. ")
else: 
  print("Im sorry what?")