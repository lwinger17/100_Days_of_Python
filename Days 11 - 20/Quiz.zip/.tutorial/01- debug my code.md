# Debug 🚫🪲 my code.

 Now that you have learned so much, your debugging skills are just getting better and better each day. Part of the fun of programming is finding that problem and squashing those bugs. 

I have given you a few programs and all of them have a significant problem. Your job is to run the program, identify from the error message where the errors are, and fix them. (HINT: Hit `run` again to see if the code is no longer broken).

I'll be honest, some of these programs have multiple errors.

Let's get to squashing those bugs!

