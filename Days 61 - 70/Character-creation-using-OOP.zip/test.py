class Character:
  def __init__(self, name, health, magic):
      self.name = name
      self.health = health
      self.magic = magic

  def talk(self):
      print(f"Name: {self.name}\nHealth: {self.health}\nMagic: {self.magic}\n")


class Player(Character):
  def __init__(self, name, health, magic, strength, lives, alive):
      super().__init__(name, health, magic)
      self.strength = strength
      self.lives = lives
      self.alive = alive

  def talk(self):
      super().talk()
      print(f"Strength: {self.strength}\nLives: {self.lives}\nAlive?: {self.alive}\n")


class Enemy(Character):
  def __init__(self, name, health, magic, type, strength):
      super().__init__(name, health, magic)
      self.type = type
      self.strength = strength

  def talk(self):
      super().talk()
      print(f"Type: {self.type}\nStrength: {self.strength}\n")


class Orc(Enemy):
  def __init__(self, name, health, magic, type, strength, speed):
      super().__init__(name, health, magic, type, strength)
      self.speed = speed

  def talk(self):
      super().talk()
      print(f"Speed: {self.speed}\n")


class Vampire(Enemy):
  def __init__(self, name, health, magic, type, day):
      super().__init__(name, health, magic, type, strength=0)  # Assuming vampires have no inherent strength
      self.day = day

  def talk(self):
      super().talk()
      print(f"Day/Night: {self.day}\n")


# Example usage
hero = Player("Lucas", 100, 40, 60, 3, "Yes")
hero.talk()

vamp1 = Vampire("Vlad", 60, 70, "Vampire", "Day")
vamp1.talk()

vamp2 = Vampire("Victor", 45, 90, "Vampire", "Day")
vamp2.talk()

orc1 = Orc("Oscar", 30, 100, "Orc", 10, 50)
orc1.talk()

orc2 = Orc("Oliver", 50, 25, "Orc", 0, 30)
orc2.talk()

orc3 = Orc("Oscar", 60, 50, "Orc", 10, 40)
orc3.talk()
