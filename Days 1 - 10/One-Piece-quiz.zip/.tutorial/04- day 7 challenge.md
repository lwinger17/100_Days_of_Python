# 👉 Day 7 Challenge
## Fake Fan Question Generator

Wanna find out if someone else is a true superfan of the same show, movie or interest as you? Create a program that asks what someone is interested in and includes nested if statements to ask annoying follow-up questions to see if someone is the real deal!

Make sure you include multiple if/elif statements and nested if statements too!

<details> <summary> 💡 Hint </summary>
The code from today is a good place to get you started.
</details>


