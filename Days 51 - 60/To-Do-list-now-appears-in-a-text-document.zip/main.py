import os
import time

todo_list = []

def pretty_print():
    print()
    for row in todo_list:
        for item in row:
            print(f"{item:^10}", end=" | ")
        print()
    print()
  
#auto save
#requires the file to already exist
f = open("toDoList.txt", "r")
todo_list = eval(f.read())
f.close()

while True:
      print("To Do List Manager:")
      print("--------------------")
      print()
      print("Press 1, 2, 3, or 4 to choose an option.")
      menu = input("1. Add to the list\n2. Remove from the list\n3. Show the current list\n4. Edit\n > ")

      if menu == "1":
        with open("toDoList.txt", "w") as f:
          f.write(str(todo_list))
        #f = open("toDoList.txt", "a+")
        name = input("What do you wish to add?: ")
        date = input("When is this due?: ")
        priority = input("What is the priority?\n (low, medium, high): ")


        row = [name, date, priority]
        todo_list.append(row)
        pretty_print()

        if row not in todo_list:
            todo_list.append(row)
        else:
            print(f"{row} is already in the list.")
            pretty_print()
        time.sleep(1)

      elif menu == "2":
          item = input("Remove > ")
          if item not in todo_list:
              print("This is not on the list.")
          else:
              approve = input("Are you sure you want to remove this? ")
              if approve.lower() == "yes":
                 for row in todo_list:
                  if item in row:
                    todo_list.remove(row)

      elif menu == "3":
          view_option = input("Do you want to view the whole list or just search for priority?\n(type 'all' to view all and type 'priority' to view based on priority): ")
          if view_option.lower() == "all":
              pretty_print()
          elif view_option.lower() == "priority":
              priority_input = input("What priority do you want to view? (low, medium, high): ")
              for row in todo_list:
                  if priority_input in row:
                      for item in row:
                          print(item, end=" | ")
                      print()
              print()
              time.sleep(4)

      elif menu == "4":
          item_to_edit = input("What would you like to edit?: ")
          for row in todo_list:
            if item_to_edit in row:
              index = todo_list.index(row)
              nname = input("What is the new name?: ")
              ndate = input("What is the new date?: ")
              npriority = input("WHat is the new prioirity?: ")

              row = [nname, ndate, npriority]
              todo_list[index] = row
              print("Updated!")
              break
            else:
              print("This is not on the list.")
              break
      time.sleep(2)
      os.system("clear")

#auto save
f = open("toDoList.txt", "w") 
f.write(str(todo_list))
f.close()

