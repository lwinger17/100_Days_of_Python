# Welcome!

## Wow, One Hundred Days?!
Yeah, that's a lot! It's a big commitment, but you'll do great! 

Python is a great language for beginners 
- It's easy to learn
- Has an active supportive community
- Offers versatile opportunities in web development, games, data science

Replit is the best place to learn to code because there's *zero* set up - which means you do not have to download, set up, or install anything. You already did all the work needed because you are here!

All you need to do now is follow along with the video, go from one chapter to the next in this tutorial panel, and just have fun! 
Now let's go!
