# Idea Maker...

Do you have brilliant ideas at inconvenient times? Do you need a handy way of storing those ideas?  Have you never heard of smartphone voice note apps? Or pens and paper?  Then, today's project is for you!

Head on over to the challenge page for all the amazing details.

