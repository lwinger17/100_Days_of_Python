# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=0r_euY8bFJw)

<details> <summary> 👀 Answer </summary>

Check out my FINAL solution in [this repl](https://replit.com/@replit/Day-100-Solution).
</details>

### Share about your journey of 100 Days of Code on Replit using #finallymyhundredthday. We want to hear from you. Tag [@Replit](https://www.twitter.com/replit). 