# https://developer.spotify.com/dashboard
from flask import Flask, request
import requests
import os
from requests.auth import HTTPBasicAuth

def getTracks(year):
    clientID = os.environ['CLIENT_ID']
    clientSecret = os.environ['CLIENT_SECRET']

    url = "https://accounts.spotify.com/api/token"
    data = {"grant_type": "client_credentials"}
    auth = HTTPBasicAuth(clientID, clientSecret)
    response = requests.post(url, data=data, auth=auth)
    access_token = response.json()["access_token"]

    offset = 0

    url = "https://api.spotify.com/v1/search"
    headers = {'Authorization': f'Bearer {access_token}'}
    search = f"?q=year%3A{year}&type=track&limit=10&offset={offset}"
    full_url = f"{url}{search}"

    response = requests.get(full_url, headers=headers)
    data = response.json()

    f = open("songs.html", "r")
    songs = f.read()
    f.close()

    list_songs = ""

    for track in data["tracks"]["items"]:
        if track["preview_url"] is not None:
            this_track = songs
            this_track = this_track.replace("{name}",f"{track['name']} by {track['artists'][0]['name']}")
            this_track = this_track.replace("{url}", track["preview_url"])
            list_songs += this_track

    return list_songs


app = Flask(__name__)

@app.route('/', methods=["POST"])
def change():
    page = ""
    f = open("form.html", "r")
    page = f.read()
    f.close()

    year = request.form["year"]
    songs = getTracks(year)
    page = page.replace("{songs}", songs)
    page = page.replace("{value}", year)
    return page

@app.route('/')
def index():
    page = ""
    f = open("form.html", "r")
    page = f.read()
    f.close()
    
    page = page.replace("{songs}", "")
    page = page.replace("{value}", "1990")

    return page

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=81)