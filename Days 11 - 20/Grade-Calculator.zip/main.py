print("Exam Grade Calculator")
print()
exam = input("What is the name of the exam you are taking?: ")
maxResult = int(input("What is the max possible score you could have achieved?: "))
result = int(input("What was your score?: "))

percentage = round(result / maxResult * 100, 2)
if percentage >= 90:
  grade = ("A+")
elif percentage >= 80 <= 90:
  grade = ("A-")
elif percentage >= 70 <= 80:
  grade = ("B")
elif percentage >= 60 <= 70:
  grade = ("C")
elif percentage >= 50 <= 60:
  grade = ("D")
else:
  grade = ("U")

print("You got a "+ str(percentage) + "% which is a " + grade + ".")