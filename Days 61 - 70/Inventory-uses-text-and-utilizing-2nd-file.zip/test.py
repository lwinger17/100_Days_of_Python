def pretty_print(inventory):
  print()
  item_counts = {}

  for row in inventory:
    for item in row:
      if item in item_counts:
          item_counts[item] += 1
      else:
          item_counts[item] = 1

  for item, count in item_counts.items():
    print(f"{item}: {count}")
print()