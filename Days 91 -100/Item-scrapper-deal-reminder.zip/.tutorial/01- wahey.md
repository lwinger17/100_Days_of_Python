# Congratulations!

This is me giving you a virtual trophy....sorry it's all I got. 

🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉
🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆🏆

You did it, folks!

On behalf of the bald master himself, plus all the amazing Replers working away behind the scenes, thank you so much for joining us for the full 💯 days.
##
If you liked this course, please share it with your friends & colleagues. 

If you have not already, please complete [this](https://forms.gle/685Vh1zCnpQAE55G8) survey so we can ensure we continue to make content that you love.

We're off for a drink and a lie down. However, we're not going to leave you without one final challenge, so read on.........
