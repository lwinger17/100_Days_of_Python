import time
print("Character Battle Simulator")
print("-------------------------------")
print()

def rollDicesHealth():
  import random
  roll1h = random.randint(1,6)
  roll2h = random.randint(1,12)
  health = (((roll1h * roll2h)/2)+10)
  return health

def rollDicesStrength():
  import random
  roll1s = random.randint(1,6)
  roll2s = random.randint(1,8)
  strength = (((roll1s * roll2s)/2)+12)
  return strength

def character1():  
  name = input("Name your character: ")
  type = input("Character type (Human, Elf, Wizard, Orc, etc.): ")
  health = rollDicesHealth()
  strength = rollDicesStrength()
  print()
  print(name, " (", type, ")")
  print("HEALTH: ", health)
  print("STRENGTH: ", strength)
  print()
  print("Sounds like a might warrior!")
  print()
  return(name, type, health, strength)

def character2():  
  name = input("Name your character: ")
  type = input("Character type (Human, Elf, Wizard, Orc, etc.): ")
  health = rollDicesHealth()
  strength = rollDicesStrength()
  print()
  print(name, " (", type, ")")
  print("HEALTH: ", health)
  print("STRENGTH: ", strength)
  print()
  print("Sounds like a might challanger!")
  print()
  return(name, type, health, strength)

#Damage is difference between strength + 1
#Roll 6 sided die to see who wins round
#If health = 0 print winner
#time.sleep between rounds
def battle():
  import random
  print("Choose your Fighters!")
  time.sleep(1)
  name1, type1, health1, strength1 = character1()
  print()
  time.sleep(1)
  name2, type2, health2, strength2 = character2()
  print()
  time.sleep(1)
  print("Let the battle begin!")
  time.sleep(1)

  while health1 > 0 and health2 > 0:
      roll1 = random.randint(1, 6)
      roll2 = random.randint(1, 6)
      if roll1 > roll2:
          print(name1, "wins the round!")
          print(name2, "takes a hit.")
          health2 -= (strength1 - strength2 + 1)
          time.sleep(1)
      else:
          print(name2, "wins the round!")
          print(name1, "takes a hit.")
          health1 -= (strength2 - strength1 + 1)
          time.sleep(1)
      print(name1, "HEALTH:", health1)
      print(name2, "HEALTH:", health2)
      print()
      time.sleep(1)

  if health2 <= 0:
      print("Oh no,", name2, "has died!")
      print(name1, "destroyed", name2, ".")
  elif health1 <= 0:
      print("Oh no,", name1, "has died!")
      print(name2, "destroyed", name1, ".")


battle()

