# 👉 Try it out


```python
counter = 0
while counter < 10:
  print(counter)
  counter +=1
  ```
Can you extend this code to print to 100?

<details> <summary> 💡 Hint </summary>

Think about your `while` condition.

</details>