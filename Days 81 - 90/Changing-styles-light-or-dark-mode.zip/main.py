from flask import Flask, redirect, request

app = Flask(__name__)

@app.route('/77')
def seventyseven():
    return redirect("https://replit.com/@lwinger")

@app.route('/', methods=["GET"])
def index():
  myName = "Test Blog Site"
  title = "May 14, 2024"
  text = "This is for fun so if you accidently find this sorry! This is just testing redirect using flask, so /# at the end will bring you to different sites."
  link = "https://replit.com/@lwinger"
  image = "KendrickLamar.png"
  page = ""
  f = open("template/portfolio.html", "r")
  page = f.read()
  f.close()
  page = page.replace("{name}", myName)
  page = page.replace("{title}", title)
  page = page.replace("{text}", text)
  page = page.replace("{image}", image)
  page = page.replace("{link}", link)

  style = request.args.get('style')
  if style == 'dark':
      page = page.replace("style.css", "style-dark.css")
  elif style == 'light':
      page = page.replace("style.css", "style-light.css")
    
  return page

@app.route('/2')
def fiftySix():
  myName = "Test Blog Site"
  title = "May 14, 2024"
  text = "Day 2 of a test blog entry"
  image = "KendrickLamar.png"
  link = "https://replit.com/@lwinger"
  page = ""
  f = open("template/portfolio.html", "r")
  page = f.read()
  f.close()
  page = page.replace("{name}", myName)
  page = page.replace("{title}", title)
  page = page.replace("{text}", text)
  page = page.replace("{image}", image)
  page = page.replace("{link}", link)
  return page

app.run(host='0.0.0.0', port=81)
