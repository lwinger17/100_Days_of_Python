from flask import Flask, request, redirect, session, render_template_string
from replit import db
import os

#If login is giving you issues type /blog to check out the blog
app = Flask(__name__, static_url_path='/static')

posts = []

myName = "lucas"

db["lucas"] = {"password": "1234"}

@app.route('/')
def index():
  if "username" in session and session["username"] == "lucas" and db.get(session["username"], {}).get("password") == "1234":
    return redirect("/blog")
  else:
    page = ""
    f = open("login.html", "r")
    page = f.read()

  return page

#log in
@app.route('/login', methods=["GET", "POST"])
def login():
  if request.method == "POST":
    form = request.form
    username = form["username"]
    password = form["password"]
    if username in db and db.get(username, {}).get("password") == password:
      session["username"] = username
      return redirect("/blog")
    else:
      return redirect("/nope")
  else:
    f = open("login.html", "r")
    page = f.read()
    f.close()
    return page

@app.route("/nope")
def nope():
  return """
    <h1> This user is not found please try again.</h1>
    <img src="static/fail.gif" height="100">
    <button type="button" onclick="location.href='/'">Try Again</button>
    """

@app.route("/blog")
def blog():
  page = render_template_string("""
    <html>
    <head>
        <link rel="stylesheet" type="text/css" href="/static/css/style.css">
    </head>
    <body>
        <h1>RandomBlogSite</h1>
        <h2>{{ myName }}'s Blog</h2>
        <form method="post" action="/addPost">
            <label for="title">Title:</label><br>
            <input type="text" id="title" name="title"><br>
            <label for="date">Date:</label><br>
            <input type="date" id="date" name="date"><br>
            <label for="text">Text:</label><br>
            <textarea id="text" name="text"></textarea><br>
            <input type="submit" value="Add Post">
        </form>
        <hr>
    {% for post in posts %}
        <h2>{{ post.title }}</h2>
        <p>{{ post.date }}</p>
        <p>{{ post.text }}</p>
        <hr>
          {% endfor %}
          </body>
          </html>
          """,
myName=myName, posts=posts)
  return page

@app.route("/addPost", methods=["POST"])
def addPost():
  title = request.form["title"]
  date = request.form["date"]
  text = request.form["text"]

  post = {"title": title, "date": date, "text": text}

  posts.append(post)

  return redirect("/blog")

@app.route("/setName", methods=["POST"])
def setName():
  session["myName"] = request.form["name"]
  return redirect("/")

@app.route("/reset")
def reset():
  session.clear()
  return redirect("/")

app.run(host='0.0.0.0', port=81)