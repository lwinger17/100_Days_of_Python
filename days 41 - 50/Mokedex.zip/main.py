#clue = {}

#def prettyPrint():
 # print()
  #for key, value in clue.items():
   # print(key, end=": ")
   # for subKey, subValue in value.items():
   #   print(subKey, subValue, end=" | ")
   # print()

#while True:
 # name = input("Name: ")
 # location = input("Location: ")
 # weapon = input("Weapon: ")

 # clue[name] = {"location": location, "weapon":weapon} #line 7

 # prettyPrint()

 # print(clue[name]["location"])
  # to get something specifict from a dictionary, you need to use the key and the subkey

import time
poke = {}

print("Mokedex")
print("----------")
print("This has no relation to the pokemon franchise")
print()
time.sleep(2)


def prettyPrint():
  print()
  print("Name | type | move | hp | mp |")
  for key, value in poke.items():
      print(key, end=" | ")
      for subKey, subValue in value.items():
          print(subValue, end=" | ")
      print()
 
  

while True:
  print("add your beast!")
  name = input("Beast Name: ")
  type = input("Type (Example: dark, fire, electric, ice, etc.): ")
  move = input("Special Move: ")
  hp = input("HP: ")
  mp = input("MP: ")
  print()
  time.sleep(1)
  poke[name] = {"type": type, "move": move, "hp": hp, "mp": mp}


  prettyPrint()
  print("----------")

  print("\033[00m Would you like to add another Beast?")
  answer = input("Y/N: ")
  if answer == "Y":
    print()
    continue
  elif answer == "N": 
    break

