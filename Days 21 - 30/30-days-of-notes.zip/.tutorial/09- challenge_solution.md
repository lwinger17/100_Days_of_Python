# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=JBJfN4aOyOY)

<details> <summary> 👀 Answer </summary>

```python
print("30 Days Down - What did you think?")
print()
for i in range(1, 31):
  thought = input(f"Day {i}:\n")
  print()
  myText = f"You thought Day {i} was"
  print(f"{myText:^35}")
  print(f"{thought:^35}")
  print()
```



</details>