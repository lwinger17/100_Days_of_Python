year = int(input("What year is it?: "))
# 365 days, 12 hours, 60 minutes, 60 seconds
normalYear = (365 * 24 * 60 * 60)
leapYear =  (366 * 24 * 60 * 60)


if year % 4 == 0:
  print("That is a leap year so there are "+ str(leapYear) + "in that year.")
else: 
  print("There are "+ str(normalYear) + "in that year.")