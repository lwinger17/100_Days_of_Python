# Share on social media

You finished your first debugging project. You are a true programmer now. 

Screenshot the output (what you see in the console of your repl), and post it to social media with the hashtag `#replit100DaysOfCode` to share your first code output with the world!

## Get connected
Join our [100 Days of Code Community](https://ask.replit.com/t/about-100-days-of-code/), and our [Discord channel](https://discord.gg/replit).

