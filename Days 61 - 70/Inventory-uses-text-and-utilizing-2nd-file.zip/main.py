import os
import test as tt
import time

# Initialize inventory
inventory = []

# Load existing inventory from file if it exists
try:
    with open("Inventory.txt", "r") as f:
        inventory = eval(f.read())
except FileNotFoundError:
    pass

while True:
    print("Inventory")
    print("--------------------")
    print()
    print("1. Add an item")
    print("2. Remove an item")
    print("3. View Inventory")

    menu = input("> ")

    if menu == "1":
        item = input("What do you wish to add?: ")
        row = [item]
        inventory.append(row)
        tt.pretty_print(inventory)
        time.sleep(1)

    elif menu == "2":
        item = input("Remove > ")
        found = False
        for row in inventory:
            if item in row:
                inventory.remove(row)
                print(f"{item} removed.")
                found = True
                break
        if not found:
            print("You do not have that.")

    elif menu == "3":
        tt.pretty_print(inventory)
        time.sleep(4)

    time.sleep(2)
    os.system("clear")

    # Save inventory to file
    with open("Inventory.txt", "w") as f:
        f.write(str(inventory))