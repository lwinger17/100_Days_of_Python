from flask import Flask, request

app = Flask(__name__)

@app.route('/', methods=["GET"])
def index():
  get = request.args
  if get["lang"].lower() == "eng":
    return "Hello, Welcome to this sad empty website!"

  elif get["lang"].lower() == "ger":
    return "Hallo, willkommen auf dieser traurigen Website!"

  elif get["lang"].lower() == "other":
    return "Hola, ¡Bienvenidos a este triste sitio web!"

  return "No Data"

app.run(host = "0.0.0.0", port = 81)
# good for storing settings but not personal info
#?lang=eng - to see the output
#/language?lang=eng

