import tkinter as tk
import random

window = tk.Tk()
window.title("Guess Who?")
window.geometry("400x300")

images = {
    "KendrickLamar.png": "Kendrick",
    "KanyeWest.png": "Kanye",
    "Drake.png": "Drake",
    "Eminem.png": "Eminem"
}
current_image = random.choice(list(images.keys()))
image = tk.PhotoImage(file=current_image)
image = image.subsample(5)
container = tk.Label(window, image=image)
container.image = image
container.pack(side="bottom")


def check_name():
    name = text.get("1.0", "end-1c").strip()
    if name in images.values():
        for key, value in images.items():
            if value == name:
                new_image = tk.PhotoImage(file=key)
                new_image = new_image.subsample(5)
                container.config(image=new_image)
                container.image = new_image
                result.config(text=f"Correct! {name} is one of the celebrities.")
                return
    result.config(text=f"Incorrect. {name} wasn't invited.")


hello = tk.Label(text="Guess the 4 celebrities in the list!")
hello.pack()

text = tk.Text(window, height=1, width=50)
text.pack()

result = tk.Label(text="", fg="black")
result.pack()

button = tk.Button(text="Check Name", command=check_name)
button.pack()

window.mainloop()
