# Fix My Code

*First, delete any other code in your `main.py` file. Copy each code snippet below into `main.py` by clicking the copy icon in the top right of each code box. Follow the directions written in green.*

```python
👉 # Solve the following problems with my code
# Your goal is to print the solution of all 3 calculations to the screen.

# multiplication
3.4 * 6.8

# division
2467 / 4673

#raise 10 to the power of 2

# print the remainder when 343 is divided by 4
print("343 // 100")
```


