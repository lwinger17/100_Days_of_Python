# Gotta Catch 'Em All.... 
### And Put Them In A Dictionary 

This challenge is all about using dictionaries to create a game about small creatures that you have captured, enslaved, and forced to fight for your amusement. You monster.

This game works in a completely non-copyright and totally lawyer friendly way. Pika-who? I have absolutely no idea what you mean..... officer.

### Go to the challenge page for details.