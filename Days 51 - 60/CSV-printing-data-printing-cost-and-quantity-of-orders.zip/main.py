import csv

#with open("January.csv") as file: 
  #reader = csv.reader(file) 
  #line = 0

  #for row in reader: 
    #print (", ".join(row)) 

print("Calculating Total")
print("=================")
print()
    
with open("Day54Totals.csv") as file: 
  reader = csv.DictReader(file) # Treats the file as a dictionary 
  total = 0
  for row in reader:
    cost = float(row["Cost"])
    quant = int(row["Quantity"])
    print (f"{cost} ({quant}) ")
    total += cost * quant
    roundTot = round(total, 2)
print(f"Total: ${roundTot}") #Outputs

#cost * quantity = total