import time
myAgenda = []
print("To Do List!")
print()
time.sleep(1)
def printList():
  for item in myAgenda:
    print(item)
  print()
  
while True:
    print()
    menu = input("Do you want to View your list or Add/Remove an item?: ")
    if menu.lower() == "add":
        item = input("What's next on the Agenda?: ")
        myAgenda.append(item)
    elif menu.lower() == "remove":
        item = input("What do you want to remove?: ")
        myAgenda.remove(item)
    elif menu.lower() == "view":
        print("Here is your current list: ")
        print()
        printList()
    else:
        print("Please choose a valid option")
        continue
printList()

