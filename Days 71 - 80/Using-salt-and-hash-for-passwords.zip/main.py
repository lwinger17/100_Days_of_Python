from replit import db
import random

while True:
  print("Login System")
  print("============")
  print()
  print("1. Add User, 2. Login")
  login = input(": ")

  if login == "1":
    username = input("Username: ")
    password = input("Password: ")
    salt = random.randint(1000, 9999)
    newPassword = f"{password}{salt}"
    newPassword = hash(newPassword)
    db[username] = {"password": newPassword, "salt": salt}

  elif login == "2":
    username = input("Username: ")
    ans = input("Password: ")

    if username in db:
      user_data = db[username]
      stored_password = user_data["password"]
      stored_salt = user_data["salt"]

      new_password = f"{ans}{stored_salt}"
      new_password = hash(new_password)

      if new_password == stored_password:
        print("Login successful")
        print()
      else:
        print("Incorrect Password")
        print()
    else:
      print("User does not exist")
      print()
