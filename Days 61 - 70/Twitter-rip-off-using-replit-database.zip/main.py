#database stores key - value 
# so you can store a list and re grab it

import time
from replit import db

tweets = db.get("tweets", [])
while True:
    print("Birder")
    print("=========")
    print("Definitely not twitter")
    print()
    print("1. Add Tweet")
    print("2. View Tweets")
    choice = input("> ")
    if choice == "1":
        tweet = input("Tweet: ")
        tweets.append(tweet)  
        db["tweets"] = tweets 
        print("Tweet saved.")
        time.sleep(1)
      
    elif choice == "2":
        saved_tweets = db.get("tweets", []) 
        print("All Tweets:")
        for i, tweet in enumerate(saved_tweets):
            print(f"{i + 1}. {tweet}")
        print()
        time.sleep(2)