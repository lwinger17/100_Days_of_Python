yellow = ["y","Y"]
red =  ["r","R"]
blue = ["b","B"]
green = ["g","G"]
purple = ["p","P"]

while True:
  myString = input("Type something: ")
  for letter in myString:
    if letter.lower() in yellow:
      print('\033[33m', end='') #yellow
    elif letter.lower() in red:
      print('\033[31m', end='') #red
    elif letter.lower() in blue:
      print('\033[34m', end='') #blue
    elif letter.lower() in green:
      print('\033[32m', end='') #green
    elif letter.lower() in purple:
      print('\033[35m', end='') #purple
    print(letter, end="")
    print('\033[0m', end='') #back to default
  print(myString)