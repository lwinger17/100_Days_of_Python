import time
from replit import db
import datetime
import random

db["entries"] = []

entries = db["entries"]

print("Diary Login")
print("=========")
print()

while True:
    print("1. Add User, 2. Login")
    login = input(": ")

    if login == "1":
        username = input("Username: ")
        password = input("Password: ")
        salt = random.randint(1000, 9999)
        newPassword = f"{password}{salt}"
        newPassword = hash(newPassword)
        db[username] = {"password": newPassword, "salt": salt}

    elif login == "2":
        while True:
            username = input("Username: ")
            ans = input("Password: ")

            if username in db:
                user_data = db[username]
                stored_password = user_data["password"]
                stored_salt = user_data["salt"]

                new_password = f"{ans}{stored_salt}"
                new_password = hash(new_password)

                if new_password == stored_password:
                    print("Login successful")
                    print()

                    if username in db:
                        while True:
                            print("Welcome Back")
                            print("1. Add Entries ")
                            print("2. View Entries")
                            choice = input("> ")
                            print()
                            if choice == "1":
                                now = datetime.datetime.now()
                                entry = input(f"{now}: ")
                                entries.append(entry)
                                db["entries"] = entries
                                print("Entry saved.")
                                time.sleep(1)
                                print()
                            elif choice == "2":
                                allEntries = db.get("entries", [])
                                print("All Entries:")
                                print()
                                for i, entry in enumerate(allEntries):
                                    entry_time = datetime.datetime.now(
                                    ).strftime('%Y-%m-%d %H:%M:%S')
                                    print(f"{entry_time}: {entry}")
                                    print()
                                time.sleep(2)
                                break
                            else:
                                print("Incorrect choice, please try again.")
                                print()
                    else:
                        print("Incorrect username or password.")
                        print()
                        time.sleep(1)
                        break

                else:
                    print("Incorrect Password")
                    print()
            else:
                print("User does not exist")
                print()
