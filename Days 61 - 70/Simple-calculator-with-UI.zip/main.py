import tkinter as tk 

window = tk.Tk()
window.title("Calculator") 
window.geometry("300x300") 

output = 0
operation = None
first_number = None

def update_output(number):
  global output
  output = output * 10 + number
  hello["text"] = output

def clear():
  global output, first_number, operation
  output = 0
  hello["text"] = output
  first_number = None
  operation = None

def perform_operation():
  global output, first_number, operation
  if first_number is None:
    first_number = output
    output = 0
  else:
    if operation == "+":
      output = first_number + output
    elif operation == "-":
      output = first_number - output
    elif operation == "x":
      output = first_number * output
    elif operation == "/":
      output = first_number / output
    first_number = None
  hello["text"] = output

def handle_operator(operator):
  global operation
  operation = operator
  perform_operation()

hello = tk.Label(text = output)
hello.grid(row=0, column=1)

button = tk.Button(text = "1",
command = lambda: update_output(1)).grid(row=1, column=0)

button = tk.Button(text = "2", 
command = lambda: update_output(2)).grid(row=1, column=1)

button = tk.Button(text = "3", 
command = lambda: update_output(3)).grid(row=1, column=2)

button = tk.Button(text = "4", 
command = lambda: update_output(4)).grid(row=2, column=0)

button = tk.Button(text = "5", 
command = lambda: update_output(5)).grid(row=2, column=1)

button = tk.Button(text = "6", 
command = lambda: update_output(6)).grid(row=2, column=2)

button = tk.Button(text = "7", 
command = lambda: update_output(7)).grid(row=3, column=0)

button = tk.Button(text = "8", 
command = lambda: update_output(8)).grid(row=3, column=1)

button = tk.Button(text = "9", 
command = lambda: update_output(9)).grid(row=3, column=2)

button = tk.Button(text = "0", 
command = lambda: update_output(0)).grid(row=4, column=1)


button = tk.Button(text = "+", 
command = lambda: handle_operator("+")).grid(row=1, column=3)

button = tk.Button(text = "-", 
command = lambda: handle_operator("-")).grid(row=1, column=4)

button = tk.Button(text = "x", 
command = lambda: handle_operator("x")).grid(row=2, column=3)

button = tk.Button(text = "/", 
command = lambda: handle_operator("/")).grid(row=2, column=4)

button = tk.Button(text = "=", 
command = perform_operation).grid(row=4, column=3)

button = tk.Button(text = "C", 
command = clear).grid(row=4, column=4)

tk.mainloop()