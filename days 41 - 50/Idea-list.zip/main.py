# 1. add an idea
# 2. load random idea
import random
import time
print("Idea notebook")
print("-----------------")
print()
day = 1
while True:
  print("Do you want to add an idea? \nDo you want to load a random idea?\n")
  print("-please input add or load")
  print()
  notebook = input("> ").lower()
  if notebook == "add": 
    f = open("IdeaNotebook.txt", "a+")
    idea = input("What is your idea: ")
    f.write(f"Idea {day}: {idea}\n")
    print(f"Idea {day}: {idea}\n")
    day += 1
    print("Added")
    time.sleep(1)
    print()
  elif notebook == "load":
      with open("IdeaNotebook.txt", "r") as f:
          ideas = f.readlines()
          rand_idea = random.choice(ideas)
          day, idea_content = rand_idea.split(":")
          print(f"{day}: {idea_content.strip()}")
          time.sleep(1)
  else:
      cont = input("Clear list? (y/n): ") 
      if cont == "y":
          open("IdeaNotebook.txt", "w").close()
          print("File Cleared")
          continue
          print()
          time.sleep(1)
      else:
          continue
f.close()
# w = write, a = append, a+ = append and create
# f points to the copy of inserted file
