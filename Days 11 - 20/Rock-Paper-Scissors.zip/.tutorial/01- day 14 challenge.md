#  2 player  🪨📄✂️

Are you ready for your first BIG project?!! 

So far you have learned 
- input and output,
- if/elif/else statements,
- basic mathematics,
- and casting as float and int.

WOW! That's alot in just 13 days.

Today, you are going to build a rock, paper, scissors game.

Start with this code below to ensure that whenever you use input, each player cannot see what the other player typed in 😉:

``` python
from getpass import getpass as input 
```

1. For this version, you have two players. Player 1 and Player 2.
2. You will need to create if statements (and probably nesting) to decide who has won, lost or if the game is a tie.
3. Make it fun and add emojis or epic comments as your players battle it out.
4. Keep it simple for you. Don't expect the user to type in the words rock, paper, scissors.  Instead, encourage them to use R, P, or S. (Can you ensure the user can still input an option even if it is typed in wrong?)


 <details> <summary> 💡 Hint </summary>
    
 Don't forget to restate the full question. `player_1 ==`. Just like you did in previous days when using logical conditions.
 
  </details>

Happy Coding! 

