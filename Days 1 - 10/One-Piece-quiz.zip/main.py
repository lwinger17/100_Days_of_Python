print("Fake fan finder")
print("----------------")

anime = input("What's your favourite Anime?: ")
if anime == "One piece" or "one piece" or "One Piece":
  print("Ok, then lets see if you are a real fan")
  character = input("Who was the first character to join the crew?: ")
  
  if character == "Zoro" or "zoro":
    print("That's correct")
    print()
    ship = input("What is the name of Luffy's second ship?:")  
    if ship == "Thousand Sunny":
      print("That is correct, you are on a role!")
      print()
      goat = input("Who is the GOAT of the Series?: ")
      if goat == "Bon Clay" or "bon clay":
        print("That's correct, you are a true fan!")
        
      elif goat == "Zoro" or "zoro" or "sanji" or "Sanji":
        print("He isn't the GOAT but he is a great character, so you pass I guess. ")
        
      else: 
        print("You might be a fan but not a true fan. Only true fans know what Bon Clay did.")
    else:
      print("That is incorrect, you are not a real fan.") 
  else: 
    print("That is incorrect.")
