#myString = "Hello there my friend."
#print(myString[0])
#print(myString[6:11])
#print(myString[:11])
#print(myString[12:])
#print(myString[::-1])
#[Start of index: after End of index: # of characters moved]

#first 3 letters
#first 2 letters
#first 2 letters of mothers maiden name
#last 2 letters of city born
print("Star Wars Name Generator")
print()
first = input("First Name: ").strip().capitalize()
last = input("Last Name: ").strip().lower()
maiden = input("Mothers Maiden Name: ").strip().capitalize()
city = input("Where were you born?: ").strip().lower()
print(f"Your Star Wars name is {first[0:3]}{last[0:2]} {maiden[0:2]}{city[-3:]}.")