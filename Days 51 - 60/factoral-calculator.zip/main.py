#helps with same output with a differnet number
#def reverse(value):
  #if value <= 0:
    #print("Done!")
   # return
    #tells it to stop 
  #else: 
    #for i in range(value):
      #print("0", end="")
    #print()
    #reverse(value - 1)
    
#reverse(8)

def factorial(n):
  if n <= 1:
    return 1
    
  result = 1
  for i in range(1, n + 1):
    result *= i
  return result
    

while True:
  print("Factorial calculator")
  print("====================")
  print()
  answer = input("What number would you like to find the factorial of?\n> ")

  num = int(answer)
  print(f"The factorial of {num} is {factorial(num)}")

  #example 5 = 5 *4 *3 * 2 * 1