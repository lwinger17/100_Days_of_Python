
for i in range(1, 31):
  thoughtsDays = input(str(f"Day {i: ^3}: "))
  #can use ^, <, >, or = to align text
  print(f"You thought that Day {i} was {thoughtsDays}")