import os
#print(os.getenv("MY_SECRET"))
#retrieves environment for key called MY_SECREt
passwordAdmin = os.environ["passwordAdmin"]
#1234
passwordGuest = os.environ["passwordGuest"]
#qwert
while True:
  userName = input("Username > ")
  if userName == "admin":
    userPass = input("Password > ")
    if userPass == passwordAdmin:
      print("Well done")
      break
    else:
      print("You dont have authorization")
      print()
  if userName == "guest":
    userPass = input("Password > ")
    if userPass == passwordGuest:
      print("Well done")
      break
    else:
      print("Please change your email")
      print()
  else:
    userPass = input("Password > ")
    print("Account not found")
    print()
  #two password admin and normie