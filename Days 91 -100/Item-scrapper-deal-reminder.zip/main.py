import requests
from bs4 import BeautifulSoup
import schedule
import time, os, random
import smtplib
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText
from replit import db

# use dict to store current price of product
# - and the price you would be willing to buy
# automate an email to notify you if the price is equal to or less than your desired price, set link as hyperlink if you can
# email has a link. reminder of price, current price

url = "https://hacksmith.store/en-us/products/mini-saber-gen-2-light-edition"
desired_price = 80

password = os.environ['mailPassword']
username = os.environ['mailUsername']

# Create a dictionary to store the prices
prices = {}

def sendMail(current_price):
    email = "Mini-Saber on Sale!"
    server = "smtp.gmail.com"
    port = 587
    s = smtplib.SMTP(host = server, port = port) 
    s.starttls()
    s.login(username, password)

    msg = MIMEMultipart()
    msg['To'] = "random gmail"
  #change this to desired recipitant
    msg['From'] = username 
    msg['Subject'] = "Mini Saber Gen 2 is under $80!" 
    # Create a hyperlink in the email
    body = f"Hacksmith Mini Saber Gen 2 is on sale!\n Current price: ${current_price}.\n <a href='{url}'>{url}</a>"
    msg.attach(MIMEText(body, 'html'))
    s.sendmail(username, "randomemail", msg.as_string())
    s.quit()

def getItem():
    response = requests.get(url)
    html = response.text

    soup = BeautifulSoup(html, 'html.parser')
    price_tag = soup.find("span", {"class" : "price price--large"})

    if price_tag:
        price_text = price_tag.text.strip()
        price_text = ''.join(filter(lambda x: x.isdigit() or x == '.', price_text))
        current_price = float(price_text)
        prices[url] = current_price
        return current_price
    else:
        return None

def printMe():
    current_price = getItem()
    if current_price is not None and current_price <= desired_price:
        sendMail(current_price)

schedule.every(24).hour.do(printMe)

while True:
  schedule.run_pending()
  time.sleep(1)