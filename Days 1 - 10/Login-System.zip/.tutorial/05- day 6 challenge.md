# 👉 Day 6 Challenge

## Make your own login program. 

1. Create a program where someone logins with their username and password correctly and then gets a lovely individual greeting.
<details> <summary> 💡 Hint  </summary>

  Remember the word `and` to make sure the username AND password are correct.
</details>

2. Write a specific personalized greeting for 3 different people.
3. Don't forget an `else` statement for everyone else who shouldn't be logging in.

