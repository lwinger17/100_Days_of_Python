# Solution (No Peeking!)


<details> <summary> 👀 Answer </summary>

```python
print("Getting to know you!")

YourName = input("What is your name?")
Hungry = input ("What is your favorite food?")
Music = input("What is your favorite music?")
WhereAreYou = input("Where are you?")

print("You are")
print(YourName)
print() 

print("You're probably hungry for")
print(Hungry)
print()
print("You're probably listening to")
print (Music)
print()
print ("You're probably living in the amazing")
print (WhereAreYou)
print() 
print ("Have a great day!")

```


</details>