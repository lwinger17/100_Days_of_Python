print("Lucas")
print("March 22 2024")

print("""
  I am signing up for this 100 days of Python challenge since its free.
  I will make sure to spend some time every day coding along, for a minimum of 10 minutes a day.
  """)

