print("Character Builder")
print("-------------------------------")
print()

def rollDicesHealth():
  import random
  roll1h = random.randint(1,6)
  roll2h = random.randint(1,12)
  health = (((roll1h * roll2h)/2)+10)
  return health

def rollDicesStrength():
  import random
  roll1s = random.randint(1,6)
  roll2s = random.randint(1,8)
  strength = (((roll1s * roll2s)/2)+12)
  return strength

while True:
  name = input("Name your character: ")
  type = input("Character type (Human, Elf, Wizard, Orc, etc.): ")
  health = rollDicesHealth()
  strength = rollDicesStrength()
  print()
  print(name, " (", type, ")")
  print("HEALTH: ", health)
  print("STRENGTH: ", strength)
  print()
  print("Sounds like a might warrior!")
  print()
  again = input("Do you want to create another character? ")
  
  if again == "Yes" or "yes":
    continue
  else: 
    break