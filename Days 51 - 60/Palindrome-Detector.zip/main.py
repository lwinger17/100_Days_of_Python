#is a word a palandrome
# racecar backwords is racecar


def reverse(word):
  return word[::-1]
while True:
  print("Palindrome Checker")
  print("=================")
  word = input("Enter a word: ")
  
  if word == reverse(word):
    print("Yes, it is a palindrome")
    print()
  else:
    print("No, it is not a palindrome")
    print()