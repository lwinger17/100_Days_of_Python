#!/bin/bash

# This script is meant for setting up a working devcontainer

# Install the Grit CLI
curl -fsSL https://docs.grit.io/install | bash
source ~/.bashrc

