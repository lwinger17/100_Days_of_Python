import os
import time

inventory = []

def pretty_print():
  print()
  item_counts = {}
  for row in inventory:
      for item in row:
          if item in item_counts:
              item_counts[item] += 1
          else:
              item_counts[item] = 1
  for item, count in item_counts.items():
      print(f"{item}: {count}")
  print()

#auto save
#requires the file to already exist
try:
    f = open("Inventory.txt", "r")
    inventory = eval(f.read())
    f.close()
except FileNotFoundError:
    pass

while True:
    print("Inventory")
    print("--------------------")
    print()
    print("1. Add an item")
    print("2. Remove an item")
    print("3. View Inventory")

    menu = input("> ")

    if menu == "1":
        with open("Inventory.txt", "w") as f:
            f.write(str(inventory))
        item = input("What do you wish to add?: ")
        row = [item]
        inventory.append(row)
        pretty_print()
        time.sleep(1)

    elif menu == "2":
        item = input("Remove > ")
        found = False
        for row in inventory:
            if item in row:
                inventory.remove(row)
                print(f"{item} removed.")
                found = True
                break
        if not found:
            print("You do not have that.")

    elif menu == "3":
        pretty_print()
        time.sleep(4)

    time.sleep(2)
    os.system("clear")

    #auto save
    with open("Inventory.txt", "w") as f:
        f.write(str(inventory))