import schedule
import time, os, random
import smtplib
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText

#Remember to use gmail app password for the mailPassword/Username secret key 

with open('quotes.txt', 'r') as file:
  quotes = [line.strip() for line in file.readlines()]

password = os.environ['mailPassword']
username = os.environ['mailUsername']

def sendMail():
  email = "Random Motivational Quote"
  server = "smtp.gmail.com"
  port = 587
  s = smtplib.SMTP(host = server, port = port) 
  s.starttls()
  s.login(username, password)

  quote = random.choice(quotes)

  msg = MIMEMultipart()
  msg['To'] = "xcvkp@example.com"
  #Can change to whoever you want to send it to
  msg['From'] = username 
  msg['Subject'] = "Take a BREAK" 
  msg.attach(MIMEText(quote, 'html'))

  s.send_message(msg)
  del msg 

def printMe():
  print("Hourly Quote: ")
  sendMail()
  
schedule.every(1).hours.do(printMe)

while True:
  schedule.run_pending()
  time.sleep(1)

