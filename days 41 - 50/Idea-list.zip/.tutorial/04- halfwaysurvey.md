# You're Halfway There! 🎊

### Tell us what you think of 100 Days of Code on Replit with [this short survey](https://forms.gle/EcgMHLwRq4oJd1zW6).