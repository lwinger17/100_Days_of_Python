# Share on Social Media


You created your third project! 🥳 WOW! Share it with the world!

Screenshot the output (what you see in the console of your repl) and post it to social media with the hashtag `#replit100DaysOfCode` to share your code output with the world!

Tomorrow we are going to publish our project to the Replit community! 

## Get connected
Join our [100 Days of Code Community](https://ask.replit.com/t/about-100-days-of-code/) and our [Discord channel](https://discord.gg/replit).