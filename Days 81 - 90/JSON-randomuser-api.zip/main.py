import requests, json
import os


# delete all files in the "images" folder
if os.path.exists("images"):
    for file in os.listdir("images"):
        os.remove(f"images/{file}")
      
for i in range (1, 11):
  result = requests.get("https://randomuser.me/api/")
  if result.status_code != 200:
    print("Error, couldn't get API")
  else:
    user = result.json() 
  
  for person in user["results"]:
    name = f"""{person["name"]["first"]} {person["name"]["last"]}"""
  
    print(name)
  
    image = f"""{person["picture"]["medium"]}"""
    picture = requests.get(image) #downloads image

    with open (f"images/{name}.jpg", "wb") as f:
      f.write(picture.content)
      
    print(f" -image saved as {name}.jpg") 