import os
import time
listOfEmail = []

def prettyPrint():
  os.system("clear")
  print("listofEmail")
  print()
  
  for index in len(listOfEmail):
    print(f"{index}: {listOfEmail[index]}")

  time.sleep(1)


while True:
  print("SPAMMER Inc.")
  menu = input("1. Add email\n2: Remove email\n3. Show emails\n4. Get SPAMMING (Have at least 10 emails in the system)\n> ")
  if menu == "1":
    email = input("Email > ")
    listOfEmail.append(email)
  elif menu =="2":
    email = input ("Email > ")
    if email in listOfEmail:
      listOfEmail.remove(email)
  elif menu == "3":
    prettyPrint()
  elif menu == "4":
    for index in range(10):
      print(f"Dear {listOfEmail[index]},\nIt has come to our attention that you have missed your car payments. Please call us at 121-213-4432 to talk to our representative to deal with this issue. As your personal information may have been hacked.\n\n DefinitlyNotHacker.org\n\nRepresentative Bob")
      time.sleep(5)
   
  time.sleep(1)
  os.system("clear")