import random
import time
print("Random Bingo Card")
print("-----------------")
print()
time.sleep(1)
my2DList = [ [1, 2, 3],
             [4, "Bingo", 5],
             [6, 7, 8] ]
#list within list
# row, column
for row in range(len(my2DList)):
  for column in range(len(my2DList[row])):
    if my2DList[row][column] != "Bingo":
      my2DList[row][column] = random.randint(1,30)

for row in my2DList:
  print(*row, sep = "|")
  print("\n","-" * 9)
