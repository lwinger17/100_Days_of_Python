import time
from replit import db
import datetime


db["entries"] = []

entries = db["entries"]


print("Diary")
print("=========")
print()
user = input("Enter your username: ")
password = input("Password: ")
while True:
        if user == "lucas" and password == "1234":
            print("Welcome Back")
            print("1. Add Entries ")
            print("2. View Entries")
            choice = input("> ")
            print()
            if choice == "1":
                now = datetime.datetime.now()
                entry = input(f"{now}: ")
                entries.append(entry)  
                db["entries"] = entries
                print("Entry saved.")
                time.sleep(1)
                print()
            elif choice == "2":
                allEntries = db.get("entries", []) 
                print("All Entries:")
                print()
                for i, entry in enumerate(allEntries):
                    entry_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    print(f"{entry_time}: {entry}")
                    print()
                time.sleep(2)
                break
    

        else:
            print("Incorrect username or password.")
            print()
            time.sleep(1)
            break