# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=qTyCw0q8a70)

<details> <summary> 👀 Answer </summary>

```python
import random
greetings = ["Hello there!", "Konnichiwa", "Guten Tag!", "Bore Da!"]
index = random.randint(0,3)
print(greetings[index])


                              
</details>