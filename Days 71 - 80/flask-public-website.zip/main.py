from flask import Flask, render_template
import datetime

app = Flask(__name__, static_url_path="/static")

@app.route('/') 
def index():
  today = datetime.date.today() # Get today's date
  page = f"""
  <html>
  <head>
    <link href="static/css/port.css" rel="stylesheet" type="text/css" />
    <title>Lucas's first public website! </title>
  </head>
  <body>
  <h1>Welcome to my website!</h1>
  <h1>{today}</h1> 
  <p>This is for fun so click the links to check out a poorly designed skill tree or a poorly designed portfolio.</p>
  
   <p><a href = "/portfolio">Portfolio</a></p>
    <p><a href = "/SkillTree"> Skill tree</a></p>

</body>

</html>

  """
  return page

@app.route('/portfolio')
def portfolio():
    page = f"""
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio </title>
     <link href="static/css/port.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <h1 > Lucas Winger's top 5 mini projects </h1>
    <p class = "blurb"> Each project here was done for a 100 days of python challange where I have learned python outside of class. Each project took at most 2 hours to complete. </p>
    <h3> 1. Seperating an CSV file to find all artists and song titles</h3>

    <img src = "static/images/SeperateCSV.png" alt="CSV Screenshot">
    <p> This project involves taking a csv of songs and creating a folder for each artist with each folder having all of the artist's songs listed. </p>

    <h3> 2. Pizzaria ordering system</h3>

    <img src = "static/images/Pizza.png" alt="Pizza">
    <p> This project runs a simulator of a pizza app with it calculating your total based on quantity, size, and tax. Each order created is saved as a list in a csv file in order to keep records of the order.  </p>

    <h3> 3. RPG inventory</h3>

    <img src = "static/images/Inventory.png" alt="Inventory">
    <p> This project looks at inventories in video games and allows you to add, remove, and view items in your inventory. these items are added to a seperate file for later and show you exactly how many of each item you have. </p>

    <h3> 4. Encrypted Diary</h3>

    <img src = "static/images/Diary.png" alt="Diary">
    <p> This project creates a secure diary that can be accessed by a previous account or by a new account. The diary has a hashed password with a random 4 digit salt. This diary saves all info to the replit database. </p>

    <h3> 5. Simple Calculator</h3>

    <img src = "static/images/calculator.png" alt = "Calculator">
    <p> This project was my first project using tkinter UI for Python, it is a simple calculator that can add, subtract, divide, and multiply.</p>

    <p> <a href = "static/https://replit.com/@lwinger"> All of my projects can be found here</m> </a></p>
    <p> (This includes both the projects you have seen here and many more.)</p>
  </body>
</html>
"""

    return page
@app.route('/SkillTree')
def skills():
    page = f"""
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkillTree </title>
     <link href="static/css/tree.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <img src = "static/images/Pic.png" alt="profile pic">
    <h1 > Lucas Winger </h1>
    <p> Junior at Concordia College majoring in Computer Science. While I have only been coding for almost 2 years I have had a lot of fun learning different languages.</p>
    <h3> Skills</h3>
    <li> Python</li>
    <li> Java </li>
    <li> Some HTML and CSS</li>
    <li> Some C++ </li>
    <li> Database management, computer security and systems, deep learning, and all of the fundamentals. </li>

    <h3> Socials</h3>
     <p> <a href = "https://github.com/lwinger17"> Github(@lwinger)</m> </a></p>

     <p> <a href = "https://www.linkedin.com/in/lucas-winger-3842112a3/"> LinkedIn (@Lucas Winger)</m> </a></p>

    <p> <a href = "https://replit.com/@lwinger"> Mini Projects(@lwinger)</m> </a></p>
</body>
</html>
"""

    return page

app.run(host='0.0.0.0', port=81)
