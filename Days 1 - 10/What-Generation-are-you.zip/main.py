print("Generation Identifier")
print("=====================")
print()
myYear = int (input("Which year were you born?:"))
if myYear >= 1883 and myYear <= 1900:
  print("You are a Lost Generation, how are you still alive?")
elif myYear >= 1901 and myYear <= 1927:
  print("You are a Greatest Generation, I wouldn't say that you're the GREATEST.")
elif myYear >= 1928 and myYear <= 1945:
  print("You are a Silent Generation, films back then must have been boring.")
elif myYear >= 1946 and myYear <= 1964:
  print("You are a Baby Boomer, you must have been a lot of fun.")
elif myYear >= 1965 and myYear <= 1980:
  print("You are a Generation X, I blame you for the housing market.")
elif myYear >= 1981 and myYear <= 1996:
  print("You are a Millennial, I also blame you for the housing market.")
elif myYear >= 1997 and myYear <= 2012:
  print("You are a Generation Z, We're part of the same generation.")
elif myYear >= 2012 and myYear <= 2023:
  print("You are a Generation Alpha, social media has rotten your brain. ")
elif myYear > 2024:
  print("You are not born yet, or you are too young to be alive.")
else:
  print("You are way too old to be alive. ")