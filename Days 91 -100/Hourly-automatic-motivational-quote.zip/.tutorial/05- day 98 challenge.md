# 👉 Day 98 Challenge

Today's challenge is all motivational. You can do it! I believe in you!

Your program should:

1. Import the motivational quotes from the text file provided.
2. Pick one at random.
3. Email yourself one random motivational quote per day.
    
Example:

![](resources/examplequotes.png)

<details> <summary> 💡 Hints </summary>
  
- Don't forget about `random.choice()` to make your random selection nice and easy.
- How many hours in a day? Think about it for scheduling.

</details>