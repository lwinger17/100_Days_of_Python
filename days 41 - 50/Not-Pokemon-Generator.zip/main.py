import time

print("Mokebeast")
print("----------")
print("This has no relation to the pokemon franchise")
print()
time.sleep(2)


#Color changes based on what type it is

while True:
  name = input("Beast Name: ")
  type = input("Type (Example: dark, fire, electric, ice, etc.): ")
  move = input("Special Move: ")
  hp = input("HP: ")
  mp = input("MP: ")
  print()
  time.sleep(1)
  dict = {"Beast Name: ": name, "Type: ": type, "Special Move: ": move, "HP: ": hp, "MP: ": mp}
  print("----------")
 
  for name, value in dict.items():
    print(f"{name} : {value}")
    if type == "fire":
      print("\033[31m")
    elif type == "water":
      print("\033[34m")
    elif type == "air":
      print("\033[37m")
    elif type == "earth":
      print("\033[32m")
    elif type == "light":
      print("\033[33m")
    elif type == "dark":
      print("\033[30m")
    elif type == "electric":
      print("\033[36m")
    elif type == "ice":
      print("\033[34m")
    elif type == "poison":
      print("\033[35m")
    

  print("\033[00m Would you like to add another Beast?")
  answer = input("Y/N: ")
  if answer == "Y":
    print()
    continue
  elif answer == "N": 
    break

