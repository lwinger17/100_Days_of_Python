class job:
  type = None
  salary = None
  hours = None
  difficult = None

  def __init__(self, type, salary, hours, difficult):
    self.type = type
    self.salary = salary
    self.hours = hours
    self.difficult = difficult
    
  def talk(self):
    print(f"Job Type: {self.type}\n Salary: {self.salary}\n Hours worked: {self.hours}")
    print(f" Difficulty: {self.difficult}")
    print()
# self = use identifier given to object

class medicine(job):
  #inheritence from animal class
  def __init__(self, college):
    self.type = "Dentist"
    self.salary = "$80,000"
    self.hours = "40"
    self.difficult = "Moderate"
    self.college = college
    
  def talk(self):
    print(f"Job Type: {self.type}\n Salary: {self.salary}\n Hours worked: {self.hours}")
    print(f" Years of school: {self.college}\n Difficulty: {self.difficult}")
    print()


print("🌟Jobs Jobs Jobs!🌟")
print("====================")
print()


dentist = medicine("5")
dentist.talk()

teacher = job("Teacher", "$60,000", "40", "Moderate")
print(teacher)

construction = job("Construction", "50,000", "80", "High")
construction.talk()

software = job("Software Engineer", "$100,000", "40", "Moderately High")
software.talk()

pizza = job("Pizza Delivery", "$15/hr", "40", "Easy")
pizza.talk()

