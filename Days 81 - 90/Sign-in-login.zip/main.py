from flask import Flask, request, redirect, session
from replit import db

app = Flask(__name__, static_url_path='/static')

db["david"] = {"password": "Baldy1"}
db["lucas"] = {"password": "1234"}


@app.route('/login', methods=["GET", "POST"])
def login():
  if request.method == "POST":
    form = request.form
    username = form["username"]
    password = form["password"]
    if username in db and db[username]["password"] == password:
      session["username"] = username
      return redirect("/yup")
    else:
      return redirect("/nope")
  else:
    f = open("login.html", "r")
    page = f.read()
    f.close()
    return page

@app.route('/signIn', methods=["GET", "POST"])
def signIn():
  if request.method == "POST":
    form = request.form
    username = form["username"]
    password = form["password"]
    confirmPassword = form["confirmPassword"]

    if username in db:
        return "Username already exists. Please choose a different username."

    if password!= confirmPassword:
        return "Passwords do not match. Please try again."

    db[username] = {"password": password}

    print(f"User {username} created with password {password}")
    return redirect("/login")
  else:
    f = open("signIn.html", "r")
    page = f.read()
    f.close()
    return page


@app.route("/nope")
def nope():
  return """<img src="static/nerdy.gif" height="100">"""


@app.route("/yup")
def yup():
  page = """<img src="static/yup.gif" height="100">"""
  f = open("change.html", "r")
  page += f.read()
  f.close()
  return page


@app.route("/changePass", methods=["POST"])
def change():
  form = request.form
  username = form["username"]
  newPassword = form["newPassword"]
  confirmNewPassword = form["confirmNewPassword"]

  if newPassword != confirmNewPassword:
    return "New passwords do not match. Please try again."

  db[username]["password"] = newPassword
  return f"""Password changed to {newPassword}"""


@app.route('/')
def index():
  if "username" in session:
    return redirect("/yup")
  else:
    page = ""
    f = open("Start.html", "r")
    page = f.read()

    return page


app.run(host='0.0.0.0', port=81)
