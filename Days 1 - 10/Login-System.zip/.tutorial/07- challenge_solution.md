# Solution (No Peeking!)

<details> <summary> 👀 Answer  </summary>

```python

print("Secure Login")
username = input("What is your username?")
password = input("What is your password?")

if username == "David" and password == "PyTh0nR*cks":
  print("Welcome, David! You are looking nice today!")
elif username == "Becky" and password == "Repl!t4evEr":
  print("Hi Becky! Love your hair today!")
elif username == "Bill" and password == "SmashTHEb*gs!":
  print("Yo! Bill! What up?!")
else:
  print("You do not have access. Go away!")
  
```






</details>