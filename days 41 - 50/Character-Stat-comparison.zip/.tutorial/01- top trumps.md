# Feel The Power Of My, erm, Stats! 

Today brings another challenge to help you practice the skills you've learned over the past few days.

In this challenge, we'll be recreating [Top Trumps](https://en.wikipedia.org/wiki/Top_Trumps), the game with the name that's been making British schoolboys snicker since 1978 (Ok, not really, but can you blame me for more British jokes?).  

This is a card based stat battling game where you can compare stats for items in a category - TV show characters, trucks, cars, planes, cheese (mmmmm).

For details of the challenge, scoot on over to - yep, you guessed it - the challenge page.

Remember, if you need extra help, please go to our [100 Days of Code Forum](https://ask.replit.com/c/100-days-of-code/30) or come to [Replit 101](https://www.eventbrite.com/e/399444046897) for live coding help from, the one and only, David!