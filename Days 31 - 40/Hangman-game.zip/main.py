import random
print("Hangman game!")
print("--------------")
print()
print("You have to figure out the word, 6 false guesses and you lose!")
print()
listOfWords = ["toast", "american", "number", "good", "evil", "waffles", "lifting"]

wordChosen = random.choice(listOfWords)
guessed_word = ["_"] * len(wordChosen)

print(" ".join(guessed_word)) 
counter = 0
while True:
    guess = input("Guess a letter: ").lower()
    if guess in wordChosen:
        print("Correct!")
        for i, char in enumerate(wordChosen):
            if char == guess:
                guessed_word[i] = guess.capitalize() 
        print(" ".join(guessed_word)) 
        if "_" not in guessed_word:
            print("Congratulations! You've won!")
            break
    elif guess not in wordChosen:
      print("Nope, not in there.")
      counter += 1
      if counter == 6:
        print("You lost!")
        break

    else:
      again = input("Want to play again?: ")
      if (again == "yes" or "Yes"):
        continue
      else:
        print("OK :(")