import time

debugMode = False
# turns off error message, turn True to turn them on
pizzaList = []


def pretty_print():
    print()
    for row in pizzaList:
        for item in row:
            print(f"{item:^10}", end=" | ")
        print()
    print()

#Helps avoid crashes

#except Exception as err:
#print("Error: unable to load")
#print(err)

try:
  f = open("PizzaShop.txt","r")
  myStuff = eval(f.read())
  f.close()
# Try to find a file and open it

except Exception:
  print("ERROR: Unable to load")

  if debugMode:
    print(traceback)


while True:
  print("THE BEST PIZZARIA")
  print("-----------------")
  print()
  print("1. Add an order")
  print("2. View order list")
  user = input("> ")

  cost = 0
  if user == "1":
    with open("PizzaShop.txt", "a+") as f:
      f.write(str(pizzaList))
      name = input("Name: ")
      top = input("Toppings: ")
      if top == "none":
        cost += 0
      else:
        cost += 2
      size = input("Size (s/m/l): ")
      if size == "l":
        cost += 12
      elif size == "m":
        cost += 10
      elif size == "s":
        cost += 8

      qt = int(input("Quantity: "))
      price =(f"$ {cost * qt} ")

      row = [name, top, size, qt, price]
      pizzaList.append(row)
      pretty_print()
      time.sleep(1)
  elif user == "2":
    pretty_print()

with open("pizzaShop.txt", "w") as f:
  f.write(str(pizzaList))