# 👉 Day 73 Challenge

Today's challenge is to start making your own web portfolio to showcase your mad coding skillz.

You should:

1. Pick 5 of your best projects from the previous 72 days.
2. Create a webpage with the title 'My Portfolio'
3. Add the heading 'Your Name - Portfolio'
4. Each of the days you are going to showcase should have:
    1. A second level heading
    2. A paragraph of explainer text.
    3. An image of each of your repls
    4. Each image should be directly linked to the repl.

## Example
```

Needs a screenshot 
```

<details> <summary> 💡 Hints </summary>
  
- Use an `<a>` tag around the `<img>` tag to create the linked image.
- Windows button + shift + 's' quick launches the snipping tool. 😁


</details>