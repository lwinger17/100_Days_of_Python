print("Math Test")
print()
#10 questions, display score
correct = 0
incorrect = 0
num = int(input("Give me a number 1-9: "))
print()

for list in range(1, 11):
  ans = input(f"{list} x {num} = ")
  if int(ans) == list * num:
    print("Correct!")
    print()
    correct += 1
  else: 
     print("Incorrect!")
     print()
     incorrect += 1

print("You got ", correct, " out of 10!")
print("You got ", incorrect, " answers wrong!")

if correct > 7:
    print("Nice Score!")
elif correct < 7 > 4:
    print("You need to study more!")
elif correct < 4 > 0:
    print("You REALLY need to study more!")
else:
    print("You are an idiot. :(")