# What do I do with libraries?


In the past, we had to hardcode the value users were looking for (remember the higher or lower guessing game...).

### With random, we can generate a number that even *we* don't know. (Sounds similar to gaming, huh?)

