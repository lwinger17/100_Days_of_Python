import csv
import os

print("Seperating CSV into folders for each artist")
print("=================")
print()

# Each folder has one file per song
with open("100MostStreamedSongs.csv") as file: 
    reader = csv.DictReader(file)  # Treat the file as a dictionary 
    next(reader)

    for row in reader:
        artist = row['Artist(s)']
        song_title = row['Song']
        Date = row["Date published"]
        # Create artist folder if it doesn't exist
        os.makedirs(artist, exist_ok=True)

        # Inside the artist folder, create a file for each song
        with open(f"{artist}/{song_title}.txt", "w") as song_file:
            song_file.write(f"Date Published: {Date}")

    print("Finished")