# 👉 Day 51 Challenge

Remember the early days when all this was just lists? 

Good! Get back over to Day 45 and grab your to do list code. You'll need it today.

Improve your to do list to add auto-save and auto-load.

That's it. Go get 'em, tiger!



<details> <summary> 💡 Hints </summary>
  
- Nothing today, just look back at the lesson and add the relevant code sections to your 'to do' program.

</details>