# Solution (No peeking!)


<details> <summary> 👀 Answer  </summary>

```python
print("Marky")
print("September 20, 2029")

print("""I am signing up for Replit's 100 days of Python challenge!
I will make sure to spend some time every day coding along, for a minimum of 10 minutes a day.
I'll be using Replit, an amazing online IDE so I can do this from my phone wherever I happen to be. No excuses for not coding from the middle of a field!""")

print("I am feeling 🥳")

print("You can follow my progress at replit.com/IamMarkProbably")

```






</details>