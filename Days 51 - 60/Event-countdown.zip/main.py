import datetime
import time

while True:
  print("Event countdown")
  print("===============")
  print()
  time.sleep(1)
  auto = input("Automatically enter todays date? (y/n): " )
  if auto == "n":
    print("What is today's date?")
    tday = int(input("Day: "))
    tmonth = int(input("Month: "))
    tyear = int(input("Year: "))
    time.sleep(1)
    print()
    event = input("What is the name of the event? \n> ")
    eday = int(input("Day: "))
    emonth = int(input("Month: "))
    eyear = int(input("Year: "))
    time.sleep(1)
    print()
    today = datetime.date(tyear, tmonth, tday)
    eventdate = datetime.date(eyear, emonth, eday)

    difference = eventdate - today
   

    if eventdate > today:
      print("Time until event!")
      print()
      print(f"Days remaining: {difference.days}.")
      print(f"{event} is coming soon!")
    elif eventdate < today:
      print("The event has passed!")
    else:
      print("Today is the event!")

  elif auto == "y":
    tdate = datetime.date.today()
    print()
    event = input("What is the name of the event? \n> ")
    eday = int(input("Day: "))
    emonth = int(input("Month: "))
    eyear = int(input("Year: "))
    time.sleep(1)
    print()
    eventdate = datetime.date(eyear, emonth, eday)
  
    difference = eventdate - tdate

    
    if eventdate > tdate:
      print("Time until event!")
      print()
      print(f"Days remaining: {difference.days}.")
     # print(f"Month: {months}.")
     # print(f"Year: {years}.")
      print(f"{event} is coming soon!")
    elif eventdate < tdate:
      print("The event has passed!")
    else:
      print("Today is the event!")
    