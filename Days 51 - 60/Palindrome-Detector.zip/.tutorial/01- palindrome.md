# A Man A Plan A Canal Panama!


Today's challenge is all about [**palindromes**](https://en.wikipedia.org/wiki/Palindrome).

A palindrome is a word that is symmetrical, (i.e. it reads the same backwards as forwards). 

For example:
- racecar
- madam
- radar

Now that you know what a palindrome is, just go back and have a look at this page title. The one that made you go, *huh?!* Got it now? Sweet!


### Hop over to the challenge page for details.