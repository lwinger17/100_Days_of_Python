import time


print("Contact Card")
print("------------")
print()
while True:
  name = input("Name: ")
  date = input("Date of Birth: ")
  phone = input("Phone number: ")
  email = input("Email: ")
  address = input("Address: ")
  
  contact = {"name":name, "date":date, "phone":phone, "email":email, "address":address}
  
  time.sleep(1)
  print()
  print()
  print(f"Name: {contact['name']}.")
  print(f"Date of Birth: {contact['date']}.")
  print(f"Phone Number: {contact['phone']}.")
  print(f"Email: {contact['email']}.")
  print(f"Address: {contact['address']}.")
  print()
  print("--------------------")
  print()
  time.sleep(1)
  print("Would you like to add another contact?")
  answer = input("Y/N: ")
  if answer == "Y":
    print()
    continue
  elif answer == "N": 
    break
    
  