import time
print("Website information notebook.")
print("-----------------------------")
print()
time.sleep(1)


while True: 
  name = input("What is the name of the website?: ")
  url = input("What is the URL?: ")
  desc = input("What is this websites purpose?: ")
  rating = int(input("WHat would you rate this out of 5?: "))
  rate = (f"{rating}/5")
  myDictionary = {"Name": name , "Ul": url, "Desc.": desc, "Rating": rate}
  print()
  time.sleep(1)
#for i in myDictionary:
  #print(myDictionary[i])

#for value in myDictionary.values():
 # print(value)

  for name, value in myDictionary.items():
    print(f"{name} : {value}")
  print()
  cont = input("Would you like to make another one? Y/N: ")
  if cont == "Y":
    continue
  elif cont == "N":
    break