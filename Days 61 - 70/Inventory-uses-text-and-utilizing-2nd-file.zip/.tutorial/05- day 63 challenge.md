# 👉 Day 63 Challenge

Today's challenge is to become your own librarian. Oook!

In the real world, programmers usually keep a library of their most useful subroutines just like this. You're going to curate your own library with these subroutines.

1. Go back through your programs and choose some subroutines that you've used *a lot*.  Perhaps it was your dice roller. Could be your prettyPrint.  Maybe it was your 'generate random baldy insult' subroutine. Whatever. Find them.
2. Create a new file that contains all your best subroutines.
3. Import this file into your main.py and call a few to show that it works.

<details> <summary> 💡 Hints </summary>
  
- You're better than this by now!  No hints today, amigos! Good luck!

</details>