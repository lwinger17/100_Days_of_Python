from flask import Flask, request, redirect, session, render_template_string

app = Flask(__name__)

# Load posts from file
try:
    with open("posts.txt", "r") as f:
        posts = [eval(line) for line in f.readlines()]
except FileNotFoundError:
    posts = []

@app.route('/')
def index():
    if request.headers.get("X-Replit-User-Name"):
        return redirect("/chat")

    page = ""
    f = open("login.html", "r")
    page = f.read()
    f.close()
    return page

@app.route("/chat")
def chat():
    if not request.headers.get("X-Replit-User-Name"):
        return redirect("/nope")

    username = request.headers.get("X-Replit-User-Name")
    pic = request.headers.get("X-Replit-User-Profile-Image")

    page = render_template_string("""
            <html>
            <head>
                <link rel="stylesheet" type="text/css" href="/static/css/style.css">
            </head>
            <body>
                <h2>Community chat</h2>
                </form>
                <hr>
            {% for post in posts %}
<div style="display: flex; flex-direction: row; align-items: center;">
    <img src="{{ post.pic }}" height="50" width="50">
    <div style="display: flex; flex-direction: column; margin-left: 10px;">
        <h2>{{ post.user }}</h2>
        <p>{{ post.text }}</p>
    </div>
</div>
{% if post.user == 'lwinger' %}
    <button type="button" onclick="deletePost({{ loop.index0 }})">Delete Post</button>
{% endif %}
<hr>
{% endfor %}
<br>
                <form method="post" action="/addPost">
                    <label for="text">Text:</label><br>
                    <textarea id="text" name="text"></textarea><br>
                    <input type="submit" value="Add Post">
                </form>
                  </body>
                  </html>
                  """,
                                username=username,
                                posts=posts)
    return page

@app.route("/addPost", methods=["POST"])
def addPost():
    text = request.form["text"]
    user = request.headers.get("X-Replit-User-Name")
    pic = request.headers.get("X-Replit-User-Profile-Image")

    posts.append({"pic": pic, "user": user, "text": text})

    # Save posts to file
    with open("posts.txt", "w") as f:
        for post in posts:
            f.write(str(post) + "\n")

    return redirect("/chat")

@app.route("/deletePost/<int:index>")
def deletePost(index):
    if request.headers.get("X-Replit-User-Name") == "lwinger":
        del posts[index]

        # Save posts to file
        with open("posts.txt", "w") as f:
            for post in posts:
                f.write(str(post) + "\n")

        return redirect("/chat")

    else:
        return "Access denied"

@app.route("/setName", methods=["POST"])
def setName():
    session["myName"] = request.form["name"]
    return redirect("/")

@app.route("/nope")
def nope():
    return """
    <h1> This user is not found please try again.</h1>
    <img src="static/fail.gif" height="100">
    <button type="button" onclick="location.href='/'">Try Again</button>
    """

app.run(host='0.0.0.0', port=81)