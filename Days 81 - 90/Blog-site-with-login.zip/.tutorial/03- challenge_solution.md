# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=hHa9HgWUkBU)

<details> <summary> 👀 Answer </summary>

Check out my solution in [this repl](https://replit.com/@replit/Day-86-Solution).


</details>

- Join our [100 Days Community](https://replit.com/100-days-help)
- Join our [Discord](https://replit.com/discord)
- Want [live support?](https://replit.com/replit-101)