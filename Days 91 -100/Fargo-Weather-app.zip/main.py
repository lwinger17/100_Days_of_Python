import requests, json
from datetime import datetime

timezone = "GMT"
latitude = 46.87719
longitude = -96.7898

result = requests.get(f"https://api.open-meteo.com/v1/forecast?latitude={latitude}&longitude={longitude}&daily=weathercode,temperature_2m_max,temperature_2m_min&timezone={timezone.upper()}")
user = result.json()

weather_code = user["daily"]["weathercode"]
tempMax = user["daily"]["temperature_2m_max"]
tempMin = user["daily"]["temperature_2m_min"]

weather_conditions = {
    0: "have Clear skies",
    1: "have Nearly clear skies",
    2: "be Partly cloudy",
    3: "be Mostly cloudy",
    4: "have Cloudy sky",
    40: "have Scattered rain showers",
    45: "have Scattered snow showers"
}

print("Fargo ND Weather")
print("================")
currentDate = datetime.now().date()
print(f"Date: {currentDate}")
print()

current_weather = "Weather condition not found"
for code in weather_code:
    if code in weather_conditions:
        current_weather = weather_conditions[code]
        break

print(f"Today will {current_weather}.")
print()

print(f"High: {max(tempMax)}°C        Low: {min(tempMin)}°C")