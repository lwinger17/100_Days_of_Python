# 👉 Day 96 Challenge

Today's challenge is to go and scrape the headlines from [hacker news](https://news.ycombinator.com/).

Your program should:

1. Only display headlines that inclue the words _Python_ or _Replit_.
    



<details> <summary> 💡 Hints </summary>
  
- Use a `for` loop to search through all the headlines.
- Use an `if` to check each headline for the key terms.

</details>