import requests
from bs4 import BeautifulSoup
import openai
import os

openai.organization = os.environ['organizationID']
openai.api_key = os.environ['openai']
openai.Model.list()

# summarized in at most 3 paragraphs
# refrences at bottom
print("Ai news summarizer ")
base_url = input("Enter the URL of a wikipedia article you want to summarize\n Example: https://en.wikipedia.org/wiki/Potato \n: ")

webpageScrape = range(1, 11)

for page in webpageScrape:
    url = base_url + "?p=" + str(page)
    response = requests.get(url)
    html = response.text

    soup = BeautifulSoup(html, 'html.parser')

    links = soup.find_all("p")
    refrences = soup.find_all(class_="citation web cs1")

    # Summarize 
    article_content = ""
    for link in links:
        article_content += link.text + "\n"

    prompt = f"Summarize the following in at most 3 paragraphs: {article_content}"
    response = openai.ChatCompletion.create(model="gpt-3.5-turbo", messages=[{"role": "user", "content": prompt}], temperature=0, max_tokens=60)
    summary = next(response["choices"])["text"].strip()
    print(f"Summary: {summary}\n")

    #references
    print("References:")
    for ref in refrences:
        print(ref.text)