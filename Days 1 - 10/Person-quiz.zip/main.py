print("What kind of person are you?")
print("============================")

player = input("Are you lazy?: ")

if player == "Yes" or "yes":
  print("Congrats you are the kind of person to lay around and do nothing.")
else: 
  print("")

player2 = input("Are you hardworking?: ")
if player2 == "Yes" or "yes":
  print("You are the kind of person to work hard and get things done.")

player3 = input("Do you like coding?:")
if player3 == "Yes" or "yes":
  print("You are someone who likes to work by themselves and complain about how nothing works")
else: "Then WTF are you doing here?"

print("If you answered no to all of these questions, then you are a liar. " )
# = changes something into another
# == are these two the same