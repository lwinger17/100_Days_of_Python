print("Guess the number!")
print("Hint: the number is between 1 and 1,000,000")

attempts = 0

while True:
  number = int(input("What is your guess?: "))
  attempts += 1
  if number == 524894:
    print("Congratulations! You somehow got the right number!")
    print("It took you "+ str(attempts) + " attempts!")
    break

  elif number > 524894:
    print("Too high")

  else:
    print("Too low")

    if attempts == 5:
      print("You need another hint, the number is even.")
    elif attempts == 10:
      print("You need another hint, the number has 6 digits!")
    elif attempts == 15:
      print("No more attempts, it's not that hard.")
    
#How many attempts it took them