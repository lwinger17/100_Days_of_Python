# Music Streaming Service

Today is a project day where you will be using your newly acquired csv reading and file management powers to work with data about a music streaming service.


## Now head over to the challenge page for the details.