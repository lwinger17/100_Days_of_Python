from flask import Flask

app = Flask(__name__)

day_number = 1

@app.route('/')
def index():
    title = f"Project Reflection"
    link = "https://replit.com/@lwinger"
    text = "By changing the number at the end you will be able to see the code for this project, and because I dont have time to implement all 78 days I will just show my latest projects, which are 70 - 78."

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

@app.route('/70')
def index1():
    title = "Day 70 Reflection"
    link = "https://replit.com/@lwinger/Using-keys-in-python"
    text = "This project taught me about using keys in coding which I have learned about but have never applied it."

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page


@app.route('/71')
def index2():
    title = "Day 71 Reflection"
    link = "https://replit.com/@lwinger/Using-salt-and-hash-for-passwords"
    text = "This project has a lot of uses and taught me a great deal about how hashing a password works."

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

@app.route('/72')
def index3():
    title = "Day 72 Reflection"
    link = "https://replit.com/@lwinger/Diary-but-with-secure-login#main.py"
    text = "This project was pretty tough as I was having a hard time saving a persons encrypted password and username in the database."

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

@app.route('/73')
def index4():
    title = "Day 72 Reflection"
    link = "https://replit.com/@lwinger/Diary-but-with-secure-login#main.py"
    text = "This project was pretty tough as I was having a hard time saving a persons encrypted password and username in the database."

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

@app.route('/74')
def index5():
    title = "Day 74 Reflection"
    link = "https://replit.com/@lwinger/Portfolio-website"
    text = "This was my first time using html to create a website."

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

@app.route('/75')
def index6():
    title = "Day 75 Reflection"
    link = "https://replit.com/@lwinger/Updated-portfolio-with-basic-CSS"
    text = "In this I applied css to my project to add style."

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

@app.route('/76')
def index7():
    title = "Day 76 Reflection"
    link = "https://replit.com/@lwinger/Basic-Link-Tree-site?v=1"
    text = "In this I created a link tree, thats about it. "

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

@app.route('/77')
def index8():
    title = "Day 77 Reflection"
    link = "https://replit.com/@lwinger/flask-public-website?v=1#main.py"
    text = "This was my first time using flask to combine python with html and css. "

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

@app.route('/78')
def index9():
    title = "Day 78 Reflection"
    link = "https://replit.com/@lwinger/Using-routes-to-show-projects#main.py"
    text = "This is the current project you are looking at. "

    page = ""
    with open("website.html", "r") as f:
        page = f.read()

    page = page.replace("{title}", title)
    page = page.replace("{text}", text)
    page = page.replace("{link}", link)

    return page

app.run(host='0.0.0.0', port=81)