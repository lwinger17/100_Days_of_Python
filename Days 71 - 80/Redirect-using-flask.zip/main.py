from flask import Flask, redirect

app = Flask(__name__)

@app.route('/77')
def seventyseven():
    return redirect("https://replit.com/@lwinger")

@app.route('/')
def index():
  myName = "Test Blog Site"
  title = "May 14, 2024"
  text = "This is for fun so if you accidenly find this sorry! This is just testing redirect using flask, so /# at the end will bring you to different sites."
  link = "https://replit.com/@lwinger"
  image = "picard.jpg"
  page = ""
  f = open("template/portfolio.html", "r")
  page = f.read()
  f.close()
  page = page.replace("{name}", myName)
  page = page.replace("{title}", title)
  page = page.replace("{text}", text)
  page = page.replace("{image}", image)
  page = page.replace("{link}", link)
  return page

@app.route('/2')
def fiftySix():
  myName = "Test Blog Site"
  title = "May 14, 2024"
  text = "Day 2 of a test blog entry"
  image = "picard.jpg"
  link = "https://replit.com/@lwinger"
  page = ""
  f = open("template/portfolio.html", "r")
  page = f.read()
  f.close()
  page = page.replace("{name}", myName)
  page = page.replace("{title}", title)
  page = page.replace("{text}", text)
  page = page.replace("{image}", image)
  page = page.replace("{link}", link)
  return page

app.run(host='0.0.0.0', port=81)
