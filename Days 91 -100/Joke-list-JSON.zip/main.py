import requests, json, time, os

jokes = []

def pretty_print(jokes):
  return '\n'.join(f"{i}. {joke}\n" for i, joke in enumerate(jokes, 1))

#auto save for txt file
try:
  with open("jokes.txt", "r") as f:
    jokes = json.loads(f.read())
except FileNotFoundError:
  pass

while True:
  print("To Do List Manager:")
  print("--------------------")
  print()
  #retrive API
  result = requests.get("https://icanhazdadjoke.com/", headers={"accept":"application/json"}) 

  #retrieve joke from API
  joke = result.json()
  print(joke["joke"])
  print()
  time.sleep(2)
  print()
  print("Press 1, 2, or 3 to choose an option.")
  menu = input("1. save joke \n2. see saved jokes \n3. new joke\n")

  if menu == "1":
    jokes.append(joke["joke"])
    print("Saved")
    time.sleep(2)
    os.system("clear")

    #save jokes to txt file
    with open("jokes.txt", "w") as f:
      f.write(pretty_print(jokes))

  elif menu == "2":
    with open("jokes.txt", "r") as f:
      print(f.read())
    time.sleep(5)
    os.system("clear")

  elif menu == "3":
    os.system("clear")

  else:
    print("Invalid input")
    time.sleep(2)
    os.system("clear")