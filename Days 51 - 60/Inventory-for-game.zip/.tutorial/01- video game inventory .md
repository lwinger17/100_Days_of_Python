# Video Game Inventory

Oh yes! It's classic RPG inventory system time.

Chug a 'stamina potion' and head to the challenge page for full details.
