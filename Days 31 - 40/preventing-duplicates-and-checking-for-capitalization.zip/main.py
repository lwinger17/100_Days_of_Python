
#.lower = all lowercase
#.upper = all uppercase
#.title = capitalizes first letter of each word
#.strip() = removes spaces

myList = []

def printList():
  print()
  for i in myList:
    print(i)
  print()

while True:
  addFirst = input("First Name: ").strip().capitalize()
  addLast = input("Last Name: ").strip().capitalize()
  name = (f"{addFirst} {addLast}")
  if name not in myList:
    myList.append(name)
    printList()
  elif name in myList:
    print("Duplicate name, try again!")
    print()