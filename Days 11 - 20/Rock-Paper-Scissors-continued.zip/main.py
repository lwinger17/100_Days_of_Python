from getpass import getpass as input
import random
#first to 3 win
#keep track of player wins

player1Wins = 0
player2Wins = 0

print("E P I C    🪨  📄 ✂️    B A T T L E")
print("First one to 3 wins!!")
while player1Wins < 3 or player2Wins < 3:
  player1 = input("Select your move (R, P, Or S): ")
  print()
  moves = ["R", "P", "S"]
  player2 = random.choice(moves)
  
  print("Player 1 > "+ player1)
  print()
  print("Player 2 > "+ player2)
  print()
  

  if (player1 == player2):
    print("Tie, Try Again")
  elif (player1 == "R" and player2 == "S"):
    print("Player 1 Wins")
    player1Wins += 1
    
  
  elif (player1 == "S" and player2 == "P"):
    print("Player 1 Wins")
    player1Wins += 1
   
  
  elif (player1 == "P" and player2 == "R"):
    print("Player 1 Wins")
    player1Wins += 1
 
    
  elif (player2 == "R" and player1 == "S"):
    print("Player 2 Wins")
    player2Wins += 1
  
    
  elif (player2 == "S" and player1 == "P"):
    print("Player 2 Wins")
    player2Wins += 1

    
  elif (player2 == "P" and player1 == "R"):
    print("Player 2 Wins")
    player2Wins += 1
   
    
  else: 
    print("Invalid Move, use only R, P, or S")


  print("Score")
  print("Player 1: ", player1Wins)
  print("Player 2: ", player2Wins)
  
if player1Wins >= 3:
    print("Player 1 Wins the Game")
    exit()
elif player2Wins >= 3:
    print("Player 2 Wins the Game")
    exit()