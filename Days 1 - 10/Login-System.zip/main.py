print("Login System")
print("---------------")

print("SECURE LOGIN")
username = input("Username > ")
password = input("Password > ")
if username == "mark" and password == "password":
  print("Welcome Mark! Make sure to wear a hat to cover your baldness :)")
elif username == "susan" and password == "1234":
  print("Hey there Susan! I thought you left this job already.......... oh well.")
elif username == "bob" and password == "5678":
  print("Welcome Bob, President of this unidentified company.")
else:
  print("You do not have access to this system. Please try again or leave. ")