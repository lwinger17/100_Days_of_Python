# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=JWYxQQtEr3s)

<details> <summary> 👀 Answer </summary>

Find the solution in [this repl](https://replit.com/@replit/Day-81-Solution).

</details>