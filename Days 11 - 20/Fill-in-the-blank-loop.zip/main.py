print("Fill in the blank lyrics!")
print("Fill in the blank spaces to see if you can figure out the song.")

while True:
  song = input("It's goin' down, I'm yellin' ______.")
  if song.lower() == "timber" or "Timber":
    print("Good job! You got it!")
    break
  print("Try Again!")