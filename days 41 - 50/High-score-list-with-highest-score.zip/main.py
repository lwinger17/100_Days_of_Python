#f = open("filenames.list", "r")
# r = read 
#while True: 
#  contents = f.readline().strip()
# stores info 
#  if contents == "":
#    break
#  print(contents)
#f.close()

#contents = contents.split()
# splits the info into a list


#contents = f.readline().strip()
#.strip() gets rid of the \n
#print(contents)
# one at a time (do this for each line)

print("High Score Table!")
print("-----------------")
print()
print("Type in your top 5 scores and we'll store them in a file for you!")
print()

hscore = 0
hscoreI = ""

for _ in range(5):
  init = input("Input your initials: ")
  score = input("Input your score: ")

  f = open("highScore.txt", "a+")

  f.write(f"{init}, {score}\n")
  print("Added")

with open("highScore.txt", "r") as file:
  for line in file:
    init, score = line.strip().split(",")
    score = int(score)
    if score > hscore:
      hscore = score
      hscoreI = init
      
  print(f"The best score is by {hscoreI} with a score of {hscore}!")
  print()
while True: 
  cont = ("Add another list? (y/n): ")
  if cont == "y":
    continue
  else:
    open("highScore.txt", "w").close()
    break
    print("File Cleared")

f.close()
  
#must open and close