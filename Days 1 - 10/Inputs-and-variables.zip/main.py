print("Getting to know you.")
print(" ")
myName = input("What is your name?: ")
myAge = input("How old are you?: ")
myFood = input("What is your favorite food?: ")
myMusic = input("What is your favorite music?: ")
myLocation = input("Where do you live?: ")
print(myName + " is " + myAge + " and lives in "+ myLocation  + " they like to eat  " + myFood + " and listen to " + myMusic + ".")
replit = input("Do you like Replit?: ")
if (replit == "Yes"):
  print("Perfect")
else: 
  print("What do you mean?")
