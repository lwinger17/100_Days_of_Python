import random

print("Infinity Dice")
print()

def dice():
    sides = int(input("How many sides will the dice have?: "))
    print()
    result = random.randint(1, sides)
    print("You rolled", result)
    print()
  
while True:
    dice()