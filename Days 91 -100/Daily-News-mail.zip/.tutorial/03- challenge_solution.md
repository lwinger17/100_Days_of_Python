# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=eJgduSxGEtY)

<details> <summary> 👀 Answer </summary>

Check out my solution in [this repl](https://replit.com/@replit/Day-99-Solution).

</details>