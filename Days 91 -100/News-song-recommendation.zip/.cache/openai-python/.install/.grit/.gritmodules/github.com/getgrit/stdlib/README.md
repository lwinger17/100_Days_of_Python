# Grit Patterns

This repository contains curated Grit patterns.

## License

This repository is licensed exclusively for usage with the Grit tool.
All rights reserved.

## Contributing

We welcome contributions from the community. Please see the [contributing guide](CONTRIBUTING.md) for more information.
