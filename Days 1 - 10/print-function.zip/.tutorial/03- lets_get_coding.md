# Let's get coding!
Let's start with some simple code to get a simple output (the information the program gives to the user).


👉 Type this line of code in `main.py` and click `run`. 



```python
print("Hello Replit")
```

(HINT: Anytime you see 👉 this means you are going to copy, add or write code in the coding editor).

If everything works as expected your console should now show you your lovely message!

<details><summary>💡Hint</summary>If you want to feel like a proper hacker, when you've finished writing your code hit `CMD + Enter`  to run your code!</details>

