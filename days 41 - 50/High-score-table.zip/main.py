print("High Score Table!")
print("-----------------")
print()
print("Type in your top 5 scores and we'll store them in a file for you!")
print()
for _ in range(5):
  init = input("Input your initials: ")
  score = input("Input your score: ")
  
  f = open("highScore.txt", "a+")
# w = write, a = append, a+ = append and create
# f points to the copy of inserted file
  f.write(f"{init}, {score}\n")
  print("Added")

f.close()
#must open and close