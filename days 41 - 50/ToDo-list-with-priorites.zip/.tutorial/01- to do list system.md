# Ta Daaaa! It's A To Do

Today is a todo list management system. Wait, we did this? Yes, but your last to do list didn't allow you to store dates or anything besides the actual list.

Your program will store a todo list, and allow you to give each task a priority.

So, what are you waiting for? Item 1, top priority. Head on over to the challenge page for details.

### Still here? Stop procrastinating!