# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=9U7lfOkJMC4)

<details> <summary> 👀 Answer </summary>

```python

import coolSubroutines as cs

cs.newPrint("red")

print("This should be red")

```

</details>

- Join our [100 Days Community](https://replit.com/100-days-help)
- Join our [Discord](https://replit.com/discord)
- Want [live support?](https://replit.com/replit-101)