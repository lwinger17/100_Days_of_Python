import tkinter as tk

window = tk.Tk()
window.title("Hello World")
window.geometry("300x400")


def choice11():
  canvas.itemconfig(container, image=Agony)
  hello2 = tk.Label(
    text=
    "The man is now incredibly frustrated and angry. He is now in a state of agony and anger. You run away from the man and he chases you. You are running away swiftly almost stumbling. You look behind and.......",
    wraplength=250)
  hello2.pack()
  button11.pack_forget()
  button12.pack_forget()
  button21.pack_forget()
  button22.pack_forget()
  button31.pack_forget()
  button32.pack_forget()


def choice12():
  canvas.itemconfig(container, image=happy)
  hello2 = tk.Label(
    text=
    "The man is happy that someone actually notices him, he thought he was invisible. He is now in a state of happiness. He is now in a state of joy.",
    wraplength=250)
  hello2.pack()
  button11.pack_forget()
  button12.pack_forget()
  button21.pack()
  button22.pack()
  button31.pack_forget()
  button32.pack_forget()


def choice21():
  canvas.itemconfig(container, image=rad)
  hello2 = tk.Label(
    text=
    "You two talk and you find out that he is actually Guy Fieri and he wants to take you out and get some food. ",
    wraplength=250)
  hello2.pack()
  button11.pack_forget()
  button12.pack_forget()
  button21.pack_forget()
  button22.pack_forget()
  button31.pack_forget()
  button32.pack_forget()


def choice22():
  canvas.itemconfig(container, image=grumpy)
  hello2 = tk.Label(
    text=
    "The man is incredibly upset, he thought you were talking to him, he tries to talk to you again to see if you will respond to him.",
    wraplength=250)
  hello2.pack()
  button11.pack_forget()
  button12.pack_forget()
  button21.pack_forget()
  button22.pack_forget()
  button31.pack()
  button32.pack()


def choice31():
  canvas.itemconfig(container, image=Agony)
  hello2 = tk.Label(
    text=
    "He has given up hope of communication, he truly thinks he is invisible, maybe even a ghost of some kind, he is upset.",
    wraplength=250)
  hello2.pack()
  button11.pack_forget()
  button12.pack_forget()
  button21.pack_forget()
  button22.pack_forget()
  button31.pack_forget()
  button32.pack_forget()


def choice32():
  canvas.itemconfig(container, image=rad)
  hello2 = tk.Label(
    text=
    "He is overjoyed by the fact that you heard him, he invitesyou to get some grub and talk about the good times. ",
    wraplength=250)
  hello2.pack()
  button11.pack_forget()
  button12.pack_forget()
  button21.pack_forget()
  button22.pack_forget()
  button31.pack_forget()
  button32.pack_forget()


canvas = tk.Canvas(window, width=200, height=150)
canvas.pack()

grumpy = tk.PhotoImage(file="grumpy.png")
grumpy = grumpy.subsample(5)

container = canvas.create_image(150, 75, image=grumpy)

hello = tk.Label(
  text=
  "You are walking down the street and you see a man that seems very upset, as he looks in your direction."
)
hello.pack()

button11 = tk.Button(text="Ignore him", command=choice11)  #grumpy - agony
button11.pack()

button12 = tk.Button(text="wave in his direction", command=choice12)
button12.pack()  #grumpy - happy

button21 = tk.Button(text="Tell him that you love food",
command=choice21)  #happy - rad
button21.pack_forget()

button22 = tk.Button(text="start talking to someone behind him", command=choice22)  #happy - grumpy
button22.pack_forget()

button31 = tk.Button(
  text="Ignore him and continue to talk to the person behind him",
  command=choice31)  #grumpy - agony
button31.pack_forget()

button32 = tk.Button(text="Talk to the man", command=choice32)  #grumpy - rad
button32.pack_forget()

rad = tk.PhotoImage(file="rad.png")
rad = rad.subsample(5)

happy = tk.PhotoImage(file="happy.png")
happy = happy.subsample(5)

Agony = tk.PhotoImage(file="Agony.png")
Agony = Agony.subsample(5)

tk.mainloop()
