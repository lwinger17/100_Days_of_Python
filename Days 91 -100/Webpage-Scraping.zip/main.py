import requests
from bs4 import BeautifulSoup


#fragile code = relies on other website (if code is changed it doesn't work)

base_url = "https://news.ycombinator.com/"
page_numbers = range(1, 11) # Scrape the first 10 pages

for page_number in page_numbers:
    url = base_url + "?p=" + str(page_number)
    response = requests.get(url)
    html = response.text

    soup = BeautifulSoup(html, 'html.parser')
  # parser = recognize tokens and makes it easier to read

    links = soup.find_all("a")
    # class extracts all tags with specific class and stores it into a list called myLinks
  
    counter = 1
    for link in links:
        
        title = link.text
        href = link.get("href")

        keywords = [" ai ", "artificial intelligence", "gemini", "chatgpt"]
        if any(keyword.lower() in title.lower() for keyword in keywords):
            print(f"{counter}. Name: {title}")
            print(f"Link: {href}\n")
            counter += 1