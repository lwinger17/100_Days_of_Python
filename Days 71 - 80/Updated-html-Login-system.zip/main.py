from flask import Flask, request
app = Flask(__name__)

valid_credentials = {
    "Lucas": "1234",
    "Tom": "qwerty",
    "Jerry": "no"
}

@app.route("/process", methods=["POST"])
def process():
    form = request.form
    username = form.get("username")
    password = form.get("password")
    page = "" 

    if username in valid_credentials and valid_credentials[username] == password:
        page += f"Welcome back {username}"
    else:
        page += "Username, email, or password is incorrect."

    return page

@app.route('/')
def index():
    page = """
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>firstLoginSystem</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<form method="post" action="/process">
    <p> Username: <input type="text" name="username" required </p>
    <p> Password: <input type="password" name="password" required></p>
    <p> <input type="hidden" name="userID" value="232"></p>
    <button type="submit"> Login </button>
</form>

<script src="script.js"></script>

</body>

</html>
    """
    return page

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=81)