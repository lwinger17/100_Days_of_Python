
myBill = float(input("What was the bill?: "))
percentage = int(input("What percentage do you want to tip?: "))
numberOfPeople = int(input("How many people?: "))

myTotal = myBill + (myBill * percentage / 100)
answer = myTotal / numberOfPeople
answer = round(answer, 2)
print("You each owe $", answer)