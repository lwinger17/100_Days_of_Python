def login():
  while True:
    user = input("Enter your username: ")
    password = input("Enter your password: ")
    if user == "Lucas" and password == "1234":
      print("Login successful!")
      break
    elif user == "Bob" and password == "password":
      print("Login successful!")
      break
    elif user == "1234r5" and password == "qwerty":
      print("Login successful!")
      break
    else:
      print("Invalid username or password.")
      print()
      continue

login()