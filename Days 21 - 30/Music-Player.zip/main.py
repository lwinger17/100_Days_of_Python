import os
import time
from replit import audio


def Play():
    source = audio.play_file('audio.wav')

while True:
    print("MyPod")
    print("Music")
    print("Player")
    time.sleep(1)

    os.system("clear")
    print("Press 1 to Play")
    print("Press 2 to Exit")
    print("Press anything else to see the menu again")
    input = int(input())
    if input == 1:
        Play()
    elif input == 2:
        exit()
    else:
        continue