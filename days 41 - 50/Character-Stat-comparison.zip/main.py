import random
import time

print("Stat competition")
print("----------------")
print("You and the computer will each choose a character, you will then choose a stat and whoever's stat is higher wins!")
print()
time.sleep(2)
while True:
    characters = {
        "Anakin Skywalker": {
            "Intelligence": 60,
            "Speed": 20,
            "Boldness": 78,
            "Charisma": 80
        },
        "Goku": {
            "Intelligence": 1,
            "Speed": 89,
            "Boldness": 92,
            "Charisma": 85
        },
        "Gandalf": {
            "Intelligence": 67,
            "Speed": 10,
            "Boldness": 68,
            "Charisma": 79
        },
        "Batman": {
            "Intelligence": 95,
            "Speed": 34,
            "Boldness": 89,
            "Charisma": 76
        },
        "The Dragonborn": {
            "Intelligence": 50,
            "Speed": 58,
            "Boldness": 85,
            "Charisma": 75
        },
        "V": {
            "Intelligence": 70,
            "Speed": 68,
            "Boldness": 80,
            "Charisma": 83
        }
    }

    print("Characters")
    print("----------")
    print()
    print("Anakin Skywalker")
    print("Goku")
    print("Gandalf")
    print("Batman")
    print("The Dragonborn (from skyrim)")
    print("V (from cyberpunk 2077")
    print()
    name = input("Choose your character: ")
    if name not in characters:
        print("Choose someone in the list above.")
        print()
        continue

    randomChar = random.choice(list(characters.keys()))

    print("The COM has chosen:", randomChar)
    print()
    stat = input("Choose a stat to compare: Intelligence, Speed, Boldness, Charisma: ")
    print()

    if stat not in characters[name]:
        print("Choose a stat from the list above.")
        print()
        continue
    elif stat == "Intelligence":
        print(name, ":", characters[name]["Intelligence"])
        print(randomChar, ":", characters[randomChar]["Intelligence"])
        if characters[name]["Intelligence"] > characters[randomChar]["Intelligence"]:
            print("You win!")
        elif characters[name]["Intelligence"] == characters[randomChar]["Intelligence"]:
            print("Draw!")
        else:
            print("You Lose!")

    elif stat == "Speed":
        print(name, ":", characters[name]["Speed"])
        print(randomChar, ":", characters[randomChar]["Speed"])
        if characters[name]["Speed"] > characters[randomChar]["Speed"]:
            print("You win!")
        elif characters[name]["Speed"] == characters[randomChar]["Speed"]:
            print("Draw!")
        else:
            print("You Lose!")

    elif stat == "Boldness":
        print(name, ":", characters[name]["Boldness"])
        print(randomChar, ":", characters[randomChar]["Boldness"])
        if characters[name]["Boldness"] > characters[randomChar]["Boldness"]:
            print("You win!")
        elif characters[name]["Boldness"] == characters[randomChar]["Boldness"]:
            print("Draw!")
        else:
            print("You Lose!")

    elif stat == "Charisma":
        print(name, ":", characters[name]["Charisma"])
        print(randomChar, ":", characters[randomChar]["Charisma"])
        if characters[name]["Charisma"] > characters[randomChar]["Charisma"]:
            print("You win!")
        elif characters[name]["Charisma"] == characters[randomChar]["Charisma"]:
            print("Draw!")
        else:
            print("You Lose!")

    print("----------")