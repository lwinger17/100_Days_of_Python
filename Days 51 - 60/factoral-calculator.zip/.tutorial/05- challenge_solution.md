# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=x0Dz-EJKz-o)

<details> <summary> 👀 Answer </summary>

```python
def factorial(value):
  if value == 1:
    return 1
  else:
    return value * factorial(value-1)

print(factorial(5))
```

</details>

- Join our [100 Days Community](https://replit.com/100-days-help)
- Join our [Discord](https://replit.com/discord)
- Want [live support?](https://replit.com/replit-101)