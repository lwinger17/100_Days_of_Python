# Solution (No Peeking!)
![](https://www.youtube.com/watch?v=4s3-namfFbU)

<details> <summary> 👀 Answer </summary>

See my solution in [this repl](https://replit.com/@replit/Day-82-Solution?v=1).

</details>