from flask import Flask, request

app = Flask(__name__)

valid_credentials = {}  # assuming this is defined somewhere

@app.route("/process", methods=["POST"])
def process():
    form = request.form
    choice = form.get("choice")
    infinite = form.get("infinite")
    food = form.get("food")

    if choice == "yes":
        page = "You are not human"
    elif infinite == "":
        page = "You are not human"
    elif food == "glorbsham":
        page = "You are not human"
    else:
        page = "Welcome human user!"

    return page

@app.route('/')
def index():
    page = """
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>AreYouARobotTest</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<form method="post" action="/process">
    <p>Do you like enjoy about politics? <input type="radio" name="choice" id="yes-radio" value="yes">
    <label for="yes-radio">Yes</label>
    <input type="radio" name="choice" id="no-radio" value="no">
    <label for="no-radio">No</label>
    </p>
    <p> What is 18/0?: <input type="text" name="infinite" required></p>


<p>
      What is your favorite food?: 
      <select name="food">
       <option value=""> </option>
        <option value="Steak">Steak</option>
        <option value="glorbsham">glorbsham</option>
        <option value="carrots">carrots</option>
      </select>
    </p>
      <button type="submit"> Login </button>
    </form>

<script src="script.js"></script>

</body>

</html>
    """
    return page


if __name__ == "__main__":
    app.run(host='0.0.0.0', port=81)