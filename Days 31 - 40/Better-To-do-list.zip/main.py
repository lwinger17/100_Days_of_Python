import os
import time
myList = []

def prettyPrint():
    os.system("clear")
    print("List")
    print("-----")
    print()
    for item in myList:
        print(f"-{item}")
    time.sleep(1)

while True:
    print("To Do List Manager:")
    print("--------------------")
    print()
    print("Press 1, 2, or 3 to choose an option.")
    menu = input("1. Add to the list\n2. Remove from the list\n3. Show the current list\n: ")
    if menu == "1":
        item = input("Add > ")
        if item not in myList:
          myList.append(item)
        else:(f"{item} is already in the list.")
          
    elif menu == "2":
        item = input("Remove > ")
        if item not in myList:
          print("This is not on the list.")
        if item in myList:
          approve = input("Are you sure you want to remove this? ")
          if approve == "yes" or "Yes":
            if item in myList:
              myList.remove(item)
              print("item successfully removed.")
    elif menu == "3":
        prettyPrint()
    time.sleep(2)
    os.system("clear")
